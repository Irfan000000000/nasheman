import React, { useEffect, useState, useContext } from 'react'
import axios from 'axios'
import ReactPaginate from 'react-paginate';
import { useAuth } from './AuthContext';
import AcademicSessionContext from './AcademicSessionContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Select from 'react-select';

function AssignSubjects() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const [totalPages, totalPagesGet] = useState("");
    const [getBanks, setBanks] = useState([]);
    const { user } = useAuth();
    const { academicSession } = useContext(AcademicSessionContext);
    const [getSections, setSections] = useState([]);
    const [getCategories, setCategories] = useState([]);
    const [getGroups, setGroups] = useState([]);


    const [assignSubject, setassignSubject] = useState([]);

    const [showList, setShowList] = useState(false);

    const [getClasses, setClasses] = useState([]);

    const initialState = {
        subject_id: [],
        class_id: "",
        section_id: "",
        session_id: academicSession,
        campus_id: user?.user?.campus_id,
        user_id: user?.user?.user_id,
        hidden_id: ''
    }

    const [validity, setValidity] = useState({
        category_id: true,
    });

    const [editFormData, setEditFormData] = useState(initialState);

    useEffect(() => {
        if (academicSession) {
            setEditFormData(prevFormData => ({
                ...prevFormData,
                session_id: parseInt(academicSession)
            }));
        }
    }, [academicSession]);





    
    useEffect(() => {
        const fetchAllCategories = () => {
          // Accessing campus_id from the nested user.user object
          const campusId = user.user.campus_id; // Replace with the correct path if needed
          console.log(campusId, "campusId"); // Log the campus_id to the
          if (campusId) {
            axios
              .get(`${process.env.REACT_APP_API_BASE_URL}/get-subjects`, {
                params: { campus_id: campusId }, // Sending campus_id as a query parameter
              })
              .then((res) => {
                setCategories(res.data.results);
              })
              .catch((err) => console.log(err));
          }
        };
    
        fetchAllCategories();
    }, [user]); // Re-fetch when the 'user' state changes


    const handleHide = () => {
        setShowList(false);
    }

    

    useEffect(() => {
        const fetchGroups = (campus_id) => {
            axios.get(process.env.REACT_APP_API_BASE_URL+`/get-fee-groups/${campus_id}`)
                .then(res => {
                    setGroups(res.data.results);
                })
                .catch(err => console.log(err));
        };

        if (user && user.user.campus_id) {
            fetchGroups(user.user.campus_id);
        }
    }, [user]);

    const validateForm = () => {
        let isValid = true;
        if (!editFormData.subject_id || editFormData.subject_id.length === 0) {
            setValidity((prevState) => ({ ...prevState, subject_id: false }));
            isValid = false;
        }
        return isValid;
    };

    const [report, getAllReports] = useState({
        from_date: '',
        to_date: '',
        report_type: ''
    });

    const [searchCategoryReport, getSearchCategoryReport] = useState({
        search: '',
    });

    function searchCategory() {
        fetchData();
    }

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            getSearchCategoryReport(searchCategoryReport);
            fetchData();
        }
    };

    function getReport() {
        if (report.report_type === "pdf") {
            // pdfReport();
        } else if (report.report_type === "excel") {
            // excelReport();
        }
    }

    useEffect(() => {
        const fetchCategory = () => {
            axios.get(process.env.REACT_APP_API_BASE_URL+"/get-banks")
                .then(res => {
                    setBanks(res.data.results);
                })
                .catch(err => console.log(err));
        };

        fetchCategory();
    }, []);

    const [totalItem, setTotalItemGet] = useState(10);

    useEffect(() => {
        if(user){
            fetchData();
        }
        
    }, [currentPage, totalItem, user]);

    const fetchData = () => {
        axios.get(process.env.REACT_APP_API_BASE_URL+"/assign-subject-classwise-list", {
            params: {
                page: currentPage,
                limit: totalItem,
                search: searchCategoryReport.search,
                campus_id: user.user.campus_id
            }
        })
            .then(res => {
                console.log(res.data.results);
                setData(res.data.results);
                setTotalCount(0);
                totalPagesGet(res.data.totalPages);
                setLoading(false);
            })
            .catch(err => console.log(err));
    };

    const handlePageChange = ({ selected }) => {
        setCurrentPage(selected + 1);
    };

    const handleTotalItemChange = (event) => {
        const newValue = event.target.value;
        setTotalItemGet(newValue);
    }

    const handleSubmit = async (e) => {

        // console.log(editFormData, "Assing Subject");

        e.preventDefault();
        if (validateForm()) {
            try {
                const response = await axios.post(process.env.REACT_APP_API_BASE_URL+'/insert-selected-subjects', editFormData, {
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                if (editFormData.hidden_id !== "") {
                    toast.success('Data updated successfully!');
                    console.log('Data Updated successfully:', response.data);
                } else {
                    toast.success('Data Inserted successfully!');
                    console.log('Data Inserted successfully:', response.data);
                }

                setEditFormData(initialState);
                fetchData();

            } catch (error) {
                if (error.response && error.response.data && error.response.data.error) {
                    toast.error(error.response.data.error);
                } else {
                    toast.error('An error occurred');
                }
            }
        }
    };

    const edit = (id_get) => {
        axios.get(process.env.REACT_APP_API_BASE_URL+`/get-selected-categories-data/${id_get}`)
            .then(response => {
                const { id, category_id } = response.data.results[0];

                setEditFormData({
                    ...editFormData,
                    category_id: [category_id] || '',
                    hidden_id: id || ''
                });
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

    const viewData = (class_id, section_id) => {

        // console.log(class_id, section_id, "Class ID and Section ID");

        setShowList(true);
            axios.get(process.env.REACT_APP_API_BASE_URL+"/view-assign-subjects-list", {
                params: {
                    session_id: academicSession,
                    campus_id: user.user.campus_id,
                    class_id: class_id,
                    section_id: section_id
                }
            }).then(res => {
                // console.log(res.data.results);
                setassignSubject(res.data.results);
            }).catch(err => {
                    console.log(err);
                    setShowList(false);
            });
    };

    const categoryOptions = getCategories.map(category => ({
        value: category.id,
        label: category.subjects
    }));

    const handleCategoryChange = (selectedOptions) => {
        let selectedCategories;
        if (Array.isArray(selectedOptions)) {
            selectedCategories = selectedOptions.map(option => option.value);
        } else {
            selectedCategories = selectedOptions ? [selectedOptions.value] : [];
        }
        setEditFormData({ ...editFormData, subject_id: selectedCategories });
        setValidity({ ...validity, subject_id: true });
    };


    useEffect(() => {
        const fetchClasses = (campus_id) => {
            axios.get(process.env.REACT_APP_API_BASE_URL+`/get-classes/${campus_id}`)
                .then(res => {
                    // console.log(res.data.results)
                    setClasses(res.data.results);
                })
                .catch(err => console.log(err));
        };

        // Ensure user.campus_id is defined before calling fetchClasses
        if (user && user.user.campus_id) {
            fetchClasses(user.user.campus_id);
        }
    }, []); // Dependencies array to re-run the effect when user changes



    const handleClassChange = (selectedOption) => {
        const [class_id, section_id] = selectedOption ? selectedOption.value.split(",") : ["", ""];
        setEditFormData({ ...editFormData, class_id, section_id });
    };


    const findClassLabel = () => {
        if (!editFormData.class_id || !editFormData.section_id) {
            return "";
        }
        const classObj = getClasses.find(class_get => class_get.id === parseInt(editFormData.class_id) && class_get.section_id === parseInt(editFormData.section_id));
        if (classObj) {
            return `${classObj.class} (${classObj.section_name})`;
        }
        return "";
    };



    const deleteSubject = (assign_subject_id) => {
            const confirmDeletion = window.confirm('Deleted! Are you sure?');
            
            if (confirmDeletion) {
                axios
                    .delete(process.env.REACT_APP_API_BASE_URL+`/delete-subject/${assign_subject_id}`)
                    .then(response => {
                        console.log('Subject deleted successfully:', response.data);
                        // Update the state to remove the deleted admission
                        setassignSubject(prevData => prevData.filter(subject => subject.id !== assign_subject_id));
                    })
                    .catch(error => {
                        console.error('Error deleting Admission:', error);
                    });
            }
        };
    

    
    return (
        <>
            <div className="d-flex">
                <div className='col-md-6 p-2'>
                    <h5 className='text-warning bg-primary p-2 card-header border'> <i class="fas fa-info-circle"></i>Assign Subjects Form</h5>
                    <form className='border p-3' onSubmit={handleSubmit}>

                    <div className="form-group row">
                            <label htmlFor="categories" className="col-sm-2 col-form-label">Class</label>
                             <div className="col-md-10">
                                {/* <label className="col-form-label">Class</label> */}
                                <Select
                                    options={getClasses.map(class_get => ({
                                        value: `${class_get.id},${class_get.section_id}`,
                                        label: `${class_get.class} (${class_get.section_name})`
                                    }))}
                                    value={
                                        editFormData.class_id && editFormData.section_id
                                            ? {
                                                value: `${editFormData.class_id},${editFormData.section_id}`,
                                                label: findClassLabel()
                                            }
                                            : null
                                    }
                                    onChange={handleClassChange}
                                    placeholder="Select Class"
                                />
                            </div>
                        </div>


                        <div className="form-group row">
                            <label htmlFor="subjects" className="col-sm-2 col-form-label">Subjects</label>
                            <div className="col-sm-10">
                                <Select
                                    id="subjects"
                                    isMulti={editFormData.hidden_id === ''}
                                    value={categoryOptions.filter(option => editFormData.subject_id.includes(option.value))}
                                    onChange={handleCategoryChange}
                                    options={categoryOptions}
                                    classNamePrefix={validity.subject_id ? 'react-select' : 'react-select invalid-input'}
                                />
                            </div>
                        </div>

                        <div className="form-group row">
                            <label htmlFor="inputEmail3" className="col-sm-2 col-form-label"></label>
                            <div className="col-sm-10 d-flex justify-content-end">
                                <input type="submit" className='btn btn-sm btn-primary' value={"Save"} onClick={handleSubmit} />
                            </div>
                        </div>
                    </form>
                </div>

                <div className='col-md-6 p-2'>
                    <div className="card-header text-warning bg-primary p-2">
                        <div className="d-flex justify-content-between align-items-center">
                            <div>
                                <i className="fas fa-list"></i> Assign Subjects List
                            </div>

                            <div className="d-flex">
                                <div className="me-2 mr-2">
                                    <input type="text" className="form-control" id="search_category" onKeyDown={handleKeyDown} onChange={(e) => getSearchCategoryReport({ ...searchCategoryReport, search: e.target.value })} />
                                </div>
                                <button className="btn btn-sm btn-danger" onClick={searchCategory} >Search</button>
                            </div>

                            <div className="d-none">
                                <div className="me-2 mr-2">
                                    <input type="date" className="form-control" id="from_date" onChange={(e) => getAllReports({ ...report, from_date: e.target.value })} />
                                </div>

                                <div className="me-2 mr-2">
                                    <input type="date" className="form-control" id="to_date" onChange={(e) => getAllReports({ ...report, to_date: e.target.value })} />
                                </div>

                                <div className="me-2 mr-2">
                                    <select name="type" id="type" className="form-control" onChange={(e) => getAllReports({ ...report, report_type: e.target.value })}>
                                        <option value="">Select Type</option>
                                        <option value="excel">Excel</option>
                                        <option value="pdf">PDF</option>
                                    </select>
                                </div>
                                <button className="btn btn-sm btn-danger" onClick={getReport} >Get Report</button>
                            </div>
                        </div>
                    </div>

                    <div className='border p-2'>
                        <div className='pb-3'>
                            <select value={totalItem} onChange={handleTotalItemChange}>
                                <option value="10">10</option>
                                <option value="20">20</option>
                                <option value="30">30</option>
                                <option value="40">40</option>
                                <option value="50">50</option>
                            </select>
                        </div>

                        <table className='table'>
                            <thead>
                                <tr>
                                    <th>Class</th>
                                    <th className='text-center'>Edit</th>
                                    <th className='text-center'>View</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading ? (
                                    <tr>
                                        <td colSpan="4">Loading...</td>
                                    </tr>
                                ) : (
                                    data.map((assign_subject, index) => (
                                        <tr key={index}>
                                            <td>{assign_subject.class + " (" + assign_subject.section_name + ")"}</td>
                                            <td className='text-center'>
                                                <div><a href="#" className='btn btn-success btn-sm' onClick={() => edit(assign_subject.id)} ><i className="fas fa-edit"></i></a></div>
                                            </td>
                                            <td className='text-center'>
                                                <div><a href="#" className='btn btn-warning btn-sm' onClick={() => viewData(assign_subject.class_id, assign_subject.section_id)}><i className="fas fa-eye"></i></a></div>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>

                        <ReactPaginate
                            previousLabel={'Previous'}
                            nextLabel={'Next'}
                            breakLabel={'...'}
                            pageCount={totalPages}
                            marginPagesDisplayed={2}
                            pageRangeDisplayed={3}
                            onPageChange={handlePageChange}
                            containerClassName={'pagination'}
                            pageClassName={'page-item'}
                            activeClassName={'active'}
                            pageLinkClassName={'page-link'}
                            previousClassName={'page-item'}
                            previousLinkClassName={'page-link'}
                            nextClassName={'page-item'}
                            nextLinkClassName={'page-link'}
                            breakClassName={'page-item'}
                            breakLinkClassName={'page-link'}
                        />
                    </div>
                </div>
            </div>


            
{
    showList && (
        <div
            style={{
                border: '1px solid #ddd',
                padding: '10px',
                position: 'fixed',
                left: '50%',
                top: '50%',
                transform: 'translate(-50%, -50%)',
                zIndex: '100',
                backdropFilter: 'blur(10px)',
                minWidth: '350px',
                maxHeight: '80vh',
                overflowY: 'auto',
                backgroundColor: 'white',
                borderRadius: '10px',
                boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                width: '1000px'
            }}
        >
            <style>
                {`
/* Custom scrollbar styles */
div::-webkit-scrollbar {
  width: 8px;
}
div::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 10px;
}
div::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 10px;
}
div::-webkit-scrollbar-thumb:hover {
  background: #555;
}
table#admission_Summary {
  border: 1px solid black;
  border-collapse: collapse;
}
table#admission_Summary th, table#admission_Summary td {
  border: 1px solid gray;
  padding: 10px !important;
}
`}
            </style>

            {/* Close Button */}
            <button
                onClick={handleHide}
                style={{
                    position: 'absolute',
                    top: '16px',
                    right: '16px',
                    background: 'transparent',
                    border: 'none',
                    fontSize: '20px',
                    cursor: 'pointer',
                    zIndex: '200', // Ensures it stays on top of other elements
                }}
            >
                &times;
            </button>

            {/* Non-Scrollable Heading */}
            <div
                style={{
                    width: '100%',
                    backgroundColor: '#007bff',
                    padding: '5px',
                    borderBottom: '1px solid #ddd',
                    position: 'sticky',
                    top: '0',
                    zIndex: '150',
                    textAlign: 'center',
                    fontSize: '18px',
                    fontWeight: 'bold',
                    color: '#ffc107',
                }}
            >
                Assign Subjects List
            </div>

            {/* Scrollable Content */}
            <div style={{ width: '100%', padding: '20px', overflowY: 'auto' }}>
                <table id="admission_Summary" border="1" cellPadding="10" style={{ "width": "100%" }}>
                    <thead>
                        <tr>
                            <th>Sr#</th>
                            <th>Subject</th>
                            <th className='text-center'>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {assignSubject.map((item, index) => (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{item.subjects}</td>
                                <td className='text-center'>
                                <div><a href="#" className='btn btn-danger btn-sm' onClick={() => deleteSubject(item.id)}><i className="fas fa-trash-alt"></i>                                                </a></div>
                                </td>

                            </tr>
                        ))}
                       
                    </tbody>
                </table>
            </div>
        </div>
    )
}


        </>
    );
}




export default AssignSubjects;
