import React, { useEffect, useState, useContext } from 'react'
import axios from 'axios'
import ReactPaginate from 'react-paginate';
import { useAuth } from './AuthContext';
import AcademicSessionContext from './AcademicSessionContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { components } from "react-select";
import Select from 'react-select';


function CreateAccount() {

    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalCount, setTotalCount] = useState(0);
    const [totalPages, totalPagesGet] = useState("");
    const [getBanks, setBanks] = useState([]);
    const { user } = useAuth();
    const { academicSession } = useContext(AcademicSessionContext);
    const [getSections, setSections] = useState([]);
      const [getClasses, setClasses] = useState([]);


      const customComponents = {
        Option: (props) => {
          return (
            <components.Option {...props}>
              <input
                type="checkbox"
                checked={props.isSelected}
                onChange={() => {}}
                style={{ marginRight: 8 }}
              />
              {props.label}
            </components.Option>
          );
        },
        MultiValue: () => null, // hide selected tags (optional)
      };


    const initialState = {

        class_id:[],
        session_id: academicSession,
        campus_id: user.user.campus_id,
        user_id: user.user.user_id,
        hidden_id: ''
    }

    const [validity, setValidity] = useState({
        class_id: true,
    });


    const [editFormData, setEditFormData] = useState(initialState);


    useEffect(() => {
        if (academicSession) {
            setEditFormData(prevFormData => ({
                ...prevFormData,
                session_id: parseInt(academicSession)
            }));
        }
    }, [academicSession]);



    useEffect(() => {
        const fetchSections = (campus_id) => {
            axios.get(process.env.REACT_APP_API_BASE_URL+`/get-sections/${campus_id}`)
                .then(res => {

                    setSections(res.data.results);
                })
                .catch(err => console.log(err));
        };

        // Ensure user.campus_id is defined before calling fetchClasses
        if (user && user.user.campus_id) {
            fetchSections(user.user.campus_id);
        }
    }, [user]); // Dependencies array to re-run the effect when user changes




    
      useEffect(() => {
        const getClasses = (campus_id) => {
          axios
            .get(process.env.REACT_APP_API_BASE_URL + `/get-classes/${campus_id}`)
            .then((res) => {
              setClasses(res.data.results);
    
              // console.log(res.data.results, "these are results");
            })
            .catch((err) => console.log(err));
        };
    
        if (user && user.user.campus_id) {
          getClasses(user.user.campus_id);
        }
      }, [user]);
    


    const classOptions = getClasses.map((classes) => ({
        value: classes.id,
        label: `${classes.class} (${classes.section_name})`,
      }));
    
    
      useEffect(() => {
        if (getClasses.length > 0) {
          const allIds = getClasses.map(classes => classes.id);
          const allNames = getClasses.map(classes => `${classes.class} (${classes.section_name})`).join(", ");
          
          setEditFormData(prevState => ({
            ...prevState,
            class_id: allIds,
            class_name: allNames
          }));
        }
      }, [getClasses]);




 






    const [report, getAllReports] = useState({
        from_date: '',
        to_date: '',
        report_type: ''
    });


    const [searchCategoryReport, getSearchCategoryReport] = useState({
        search: '',
    });




    function searchCategory() {
        fetchData();
    }


    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            getSearchCategoryReport(searchCategoryReport);
            fetchData();
        }
    };




    function getReport() {
        if (report.report_type == "pdf") {
            // pdfReport();
        } else if (report.report_type == "excel") {
            // excelReport();
        }
    }


    useEffect(() => {
        const fetchCategory = () => {
            axios.get(process.env.REACT_APP_API_BASE_URL+"/get-banks")
                .then(res => {
                    setBanks(res.data.results);
                })
                .catch(err => console.log(err));
        };

        fetchCategory();
    }, []); // Empty dependency array ensures this effect runs only once, on mount




    //const [itemsPerPage, setitemsPerPage] = useState(10); 

    const [totalItem, setTotalItemGet] = useState(10);

    // const itemsPerPage = 10;

    useEffect(() => {
        fetchData();
    }, [currentPage, totalItem, user]);





    const fetchData = () => {
        axios.get(process.env.REACT_APP_API_BASE_URL+"/sections-list", {
            params: {
                page: currentPage,
                limit: totalItem,
                search: searchCategoryReport.search,
                campus_id: user.user.campus_id
            }
        })
            .then(res => {
                console.log(res.data.results);
                setData(res.data.results);
                setTotalCount(0);
                totalPagesGet(res.data.totalPages);
                setLoading(false);
            })
            .catch(err => console.log(err));
    };

    const handlePageChange = ({ selected }) => {
        setCurrentPage(selected + 1);
    };

    const handleTotalItemChange = (event) => {

        const newValue = event.target.value;
        setTotalItemGet(newValue);

    }






    const handleSubmit = async (e) => {
        e.preventDefault();
        // if (validateForm()) {
            try {
                const response = await axios.post(process.env.REACT_APP_API_BASE_URL+'/insert-student-account', editFormData, {
                    headers: {
                        'Content-Type': 'application/json', // Set content type to JSON
                    },
                });

                console.log(response.data.students);
    
                    toast.success('Students Account Created Successfully!');

                setEditFormData(initialState); // Reset form data after successful submission
                // fetchData();
    
            } catch (error) {
                if (error.response && error.response.data && error.response.data.error) {
                    toast.error(error.response.data.error); // Show the error message from the server
                } else {
                    toast.error('An error occurred'); // Show a generic error message
                }
            }
        // }
    };
    




    const edit = (id_get) => {
        axios.get(process.env.REACT_APP_API_BASE_URL+`/get-section-data/${id_get}`)
            .then(response => {
              
                const { id, section_name } = response.data.results[0];
                console.log(section_name);
                setEditFormData({ ...editFormData, 
                    section_name: section_name || '',
                    hidden_id: id || ''
                });
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }




  
    const deleteRow = (id_get) => {
        var confirm_delete = window.confirm("Deleted! Are you sure?");
        
        if (confirm_delete) {
          axios.put(process.env.REACT_APP_API_BASE_URL+`/soft-delete-section/${id_get}`)
            .then(response => {
              console.log('Status updated successfully:', response.data);
              // Update the state to reflect the change in status
              setData(prevData => prevData.filter(classes => classes.id !== id_get));
            })
            .catch(error => {
              console.error('Error updating status:', error);
            });
        }
      };
      

    return (
        <>
            <div className="d-flex">
                <div className='col-md-6 p-2'>
                    <h5 className='text-warning bg-primary p-2 card-header border'> <i className="fas fa-sign-in-alt"></i>  Create Students Account</h5>
                    <form className='border p-3' onSubmit={handleSubmit}>

                       

                        <div className="d-flex justify-content-end">
                                     
                                   <button
                         type="button"
                         className={`btn mb-2 px-3 py-2 shadow-sm text-white fw-bold border-0 ${
                           editFormData.class_id.length === getClasses.length
                             ? 'bg-primary'
                             : 'bg-gradient bg-success'
                         }`}
                         style={{ transition: 'all 0.3s ease' }}
                         onClick={() => {
                           const allIds = getClasses.map((cls) => cls.id);
                           const allNames = getClasses
                             .map((cls) => `${cls.class} (${cls.section_name})`)
                             .join(', ');
                       
                           if (editFormData.class_id.length === getClasses.length) {
                             // Unselect all
                             setEditFormData({
                               ...editFormData,
                               class_id: [],
                               class_name: '',
                             });
                           } else {
                             // Select all
                             setEditFormData({
                               ...editFormData,
                               class_id: allIds,
                               class_name: allNames,
                             });
                           }
                       
                           setValidity({ ...validity, class_id: true });
                         }}
                       >
                         <i
                           className={`fas ${
                             editFormData.class_id.length === getClasses.length ? 'fa-times-circle' : 'fa-check-circle'
                           } me-2`}
                         ></i>
                         {editFormData.class_id.length === getClasses.length
                           ? ' Unselect All Classes'
                           : ' Select All Classes'}
                       </button>
                       
                                   </div>
                       
                                   <div className="form-group row">
                                     <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                                       Class
                                     </label>
                                     <div className="col-sm-10">
                                       <Select
                                         name="class_ids"
                                         options={classOptions} // Remove SELECT_ALL_OPTION from options
                                         isMulti
                                         closeMenuOnSelect={false}
                                         hideSelectedOptions={false}
                                         components={customComponents}
                                         placeholder="Select classes..."
                                         value={classOptions.filter((option) =>
                                           editFormData.class_id.includes(option.value)
                                         )}
                                         onChange={(selectedOptions) => {
                                           // Remove all logic related to SELECT_ALL_OPTION
                                           const filteredOptions = selectedOptions || [];
                                           const selectedIds = filteredOptions.map((opt) => opt.value);
                                           const selectedNames = filteredOptions
                                             .map((opt) => opt.label)
                                             .join(", ");
                       
                                           setEditFormData({
                                             ...editFormData,
                                             class_id: selectedIds,
                                             class_name: selectedNames,
                                           });
                       
                                           setValidity({ ...validity, class_id: true });
                                         }}
                                         className={
                                           validity.class_id
                                             ? "react-select-container"
                                             : "react-select-container invalid-input"
                                         }
                                         classNamePrefix="react-select"
                                       />
                                     </div>
                                   </div>



                        <div className="form-group row">
                            <label htmlFor="inputEmail3" className="col-sm-2 col-form-label"></label>
                            <div className="col-sm-10 d-flex justify-content-end">
                                <input type="submit" className='btn btn-sm btn-primary' value={"Save"} onClick={handleSubmit} />
                            </div>
                        </div>

                    </form>
                </div>

                
            </div>

        </>
    )



}

export default CreateAccount