import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';
import AcademicSessionContext from './AcademicSessionContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import ReactPaginate from 'react-paginate';
import Select from 'react-select';
import { components } from "react-select";
import SingleFeeGenerate from './SingleFeeGenerate';
import FeeVouchers from './FeeVouchers';
// const SELECT_ALL_OPTION = {
//   value: "*",
//   label: "Select All Classes",
// };

const customComponents = {
  Option: (props) => {
    return (
      <components.Option {...props}>
        <input
          type="checkbox"
          checked={props.isSelected}
          onChange={() => {}}
          style={{ marginRight: 8 }}
        />
        {props.label}
      </components.Option>
    );
  },
  MultiValue: () => null, // hide selected tags (optional)
};

function FeeGenerate() {
  const [data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(0);
  // const [loading, setLoading] = useState(true);
  // const [getCategories, setCategories] = useState([]);
  const [getClasses, setClasses] = useState([]);
  // const [getFeeHeads, setFeeHeads] = useState([]);
  const { user } = useAuth();
  const { academicSession } = useContext(AcademicSessionContext);
  const [filteredData, setFilteredData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [checkHead, setCheckHead] = useState('');
  const itemsPerPage = 10;

  // Calculate the offset and the slice of data to display on the current page
  const offset = currentPage * itemsPerPage;
  const currentItems = filteredData.slice(offset, offset + itemsPerPage);
  const pageCount = Math.ceil(filteredData.length / itemsPerPage);

  // Handle page click
  const handlePageClick = ({ selected }) => {
    setCurrentPage(selected);
  };

  const handleSearch = () => {
    const filtered = data.filter(
      (item) =>
        item.head_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.category.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.shift.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredData(filtered);
    setCurrentPage(0); // Reset to the first page after search
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  // State to keep track of selected items
  const [selectedItems, setSelectedItems] = useState([]);

  // Initialize selected items when data changes
  // useEffect(() => {
  //     const initialSelectedItems = data.map(head_detail => ({
  //         id: head_detail.id,
  //         amount: head_detail.amount,
  //         category_id: head_detail.category_id,
  //         category_name: head_detail.category,
  //         head_name: head_detail.head_name,
  //     }));
  //     setSelectedItems(initialSelectedItems);
  // }, [data]);

  // Extract unique head names for group selection
  const uniqueHeadNames = [...new Set(data.map((item) => item.head_name))];

  const initialState = {
    class_id: [],
    class_name: "",
    shift: "",
    from_month: "",
    to_month: "",
    due_date: "",
    remarks: "",
    heads_with_amount: "",
    category_id: "",
    fee_group_id: "",
    amount: "",
    fine: 0,
    arrear_set: true,
    bus_fee_status: true,
    session_id: academicSession,
    campus_id: user.user.campus_id,
    user_id: user.user.user_id,
    hidden_id: "",
  };

  const [validity, setValidity] = useState({
    class_id: true,
    shift: true,
    from_month: true,
    due_date: true,
  });

  const [editFormData, setEditFormData] = useState(initialState);

  // Update session_id when academicSession changes
  useEffect(() => {
    if (academicSession) {
      setEditFormData((prevFormData) => ({
        ...prevFormData,
        session_id: parseInt(academicSession),
      }));
    }
  }, [academicSession]);

  // Validate form data
  const validateForm = () => {
    let isValid = true;
    if (!editFormData.class_id) {
      setValidity((prevState) => ({ ...prevState, class_id: false }));
      isValid = false;
    }
    // if (!editFormData.shift.trim()) {
    //   setValidity((prevState) => ({ ...prevState, shift: false }));
    //   isValid = false;
    // }
    if (!editFormData.from_month.trim()) {
      setValidity((prevState) => ({ ...prevState, from_month: false }));
      isValid = false;
    }
    if (!editFormData.due_date.trim()) {
      setValidity((prevState) => ({ ...prevState, due_date: false }));
      isValid = false;
    }

    return isValid;
  };

  // const [report, getAllReports] = useState({
  //   from_date: "",
  //   to_date: "",
  //   report_type: "",
  // });

  useEffect(() => {
    const getClasses = (campus_id) => {
      axios
        .get(process.env.REACT_APP_API_BASE_URL + `/get-classes/${campus_id}`)
        .then((res) => {
          setClasses(res.data.results);

          // console.log(res.data.results, "these are results");
        })
        .catch((err) => console.log(err));
    };

    if (user && user.user.campus_id) {
      getClasses(user.user.campus_id);
    }
  }, [user]);


  //this is old code and this is accurate ..............................
//   useEffect(() => {
//       setSelectedItems([]); // Reset selected items when class_id or shift changes
//       const getClasses = async (campus_id, class_id, shift) => {
//           try {
//               const voucher_type = 'multiple_voucher_form';
//               const res = await axios.get(process.env.REACT_APP_API_BASE_URL+`/get-fee-heads-details-for-vouchers/${campus_id}/${class_id}/${shift}/${voucher_type}`);
//               setData(res.data.results);
//               setFilteredData(res.data.results); // Initialize filtered data

//           } catch (err) {
//               console.log(err);
//           } finally {
//               setLoading(false);
//           }
//       };

//       if (user?.user?.campus_id && editFormData.class_id && editFormData.shift) {
//           setLoading(true);
//           getClasses(user.user.campus_id, editFormData.class_id, editFormData.shift);
//       }
//   }, [editFormData.class_id, editFormData.shift, user]);




// useEffect(() => {
//     setSelectedItems([]); // Reset selected items when class_id or shift changes
//     const getHeadsDetail = async (campus_id) => {
//         try {
//             const voucher_type = 'multiple_voucher_form';
//             const res = await axios.get(process.env.REACT_APP_API_BASE_URL+`/get-fee-heads-details-for-vouchers/${campus_id}/${voucher_type}`);
//             setData(res.data.results);
//             setFilteredData(res.data.results); // Initialize filtered data

//         } catch (err) {
//             console.log(err);
//         } finally {
//             setLoading(false);
//         }
//     };

//     if (user?.user?.campus_id) {
//         setLoading(true);
//         getHeadsDetail(user.user.campus_id);
//     }
// }, [user]);





  //this is new code (if any issue occur then delete this code) ..............................
  useEffect(() => {
    // console.log("hitted");
    setSelectedItems([]); // Reset selected items when class_id or shift changes
    const getHeadsDetail = async (campus_id) => {
      try {
        const voucher_type = "multiple_voucher_form";
        const res = await axios.get(
          process.env.REACT_APP_API_BASE_URL +
            `/get-fee-heads-details-for-vouchers/${campus_id}/${voucher_type}`);
        const fetchedData = res.data.results;

        // Pre-select the "always_checked" fee heads
        const selectedAlwaysChecked = fetchedData.filter(
          (item) => item.checked_status === "always_checked"
        );
        const alwaysCheckedItems = selectedAlwaysChecked.map((item) => ({
          id: item.id,
          amount: item.amount,
          category_id: item.category_id,
          category_name: item.category,
          head_name: item.head_name,
          fee_group_id: item.fee_group_id,
          shift_head: item.shift
        }));

        setData(fetchedData);
        setFilteredData(fetchedData);
        setSelectedItems((prevSelectedItems) => [
          ...prevSelectedItems,
          ...alwaysCheckedItems,
        ]); // Add always checked items to selected
      } catch (err) {
        console.log(err);
      } finally {
        // setLoading(false);
      }
    };

    if (user?.user?.campus_id) {
      // setLoading(true);
      getHeadsDetail(
        user.user.campus_id
      );
    }
  }, [user]);






  const handleSubmit = async (e) => {
    e.preventDefault();
    if (selectedItems.length <= 0) {
      toast.error("No fee head selected!");
      return;
    }
    if (validateForm()) {
      let groupedData = {};
      selectedItems.forEach((item) => {
        //DONT DELETE BELOW CODE
        // const { category_id, ...rest } = item;

        const { category_id, shift_head, fee_group_id, head_name, ...rest } = item;

        let category_detail = category_id+shift_head+fee_group_id;

        if (groupedData[category_detail]) {
          groupedData[category_detail].push(rest);
        } else {
          groupedData[category_detail] = [rest];
        }
      });


    //   console.log(groupedData);

    //   return false;

      const combinedData = {
        editFormData,
        groupedData,
      };

      try {
        const response = await axios.post(
          process.env.REACT_APP_API_BASE_URL + "/fee-voucher",
          combinedData,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        const responseData = response.data;

        if (responseData.message === "greater_month") {
          toast.error("Voucher month should be greater! Last Entry Voucher");
        } else {
          toast.success("Fee vouchers inserted successfully!");
          setEditFormData({ ...editFormData, class_id: "" });
          // setSelectedItems([]); // Reset selected items when class_id or shift changes
          // setEditFormData({ ...editFormData, class_id: '' });
        }
      } catch (error) {
        console.error("Error:", error);
        // Handle axios error response
        if (error.response) {
          // Server responded with a status other than 2xx
          console.error("Server Response Error:", error.response);
        } else if (error.request) {
          // No response received
          console.error("No Response from Server:", error.request);
        } else {
          // Other errors
          console.error("Error:", error.message);
        }
      }

      // try {
      //     const response = await fetch(process.env.REACT_APP_API_BASE_URL+'/fee-voucher', {
      //         method: 'POST',
      //         headers: {
      //             'Content-Type': 'application/json',
      //         },
      //         body: JSON.stringify(combinedData),
      //     });

      //     if (!response.ok) {
      //         throw new Error('Network response was not ok');
      //     }

      //     const responseData = await response.json();

      //     if (responseData.message === "greater_month") {
      //         toast.error("Voucher month should be greater! Last Entry Voucher");
      //     } else {
      //         toast.success('Fee vouchers inserted successfully!');
      //         // setEditFormData({ ...editFormData, class_id: '' });
      //     }
      // } catch (error) {
      //     console.error('Error:', error);
      // }
    }
  };

  const handleCheckboxChange = (
    id,
    amount,
    category_id,
    category_name,
    head_name
  ) => {
    setSelectedItems((prevSelectedItems) => {
      const isSelected = prevSelectedItems.some((item) => item.id === id);
      if (isSelected) {
        return prevSelectedItems.filter((item) => item.id !== id);
      } else {
        return [
          ...prevSelectedItems,
          { id, amount, category_id, category_name, head_name },
        ];
      }
    });
  };

  // Handle group checkbox change for each head_name
  const handleGroupCheckboxChange = (head_name) => {
    const itemsToToggle = data.filter((item) => item.head_name === head_name);
    const areAllSelected = itemsToToggle.every((item) =>
      selectedItems.some((selected) => selected.id === item.id)
    );

    if (areAllSelected) {
      // Remove all items with the given head_name
      setSelectedItems((prevSelectedItems) =>
        prevSelectedItems.filter((item) => item.head_name !== head_name)
      );
    } else {
      // Add all items with the given head_name
      const itemsToAdd = itemsToToggle
        .filter(
          (item) => !selectedItems.some((selected) => selected.id === item.id)
        )
        .map((item) => ({
          id: item.id,
          amount: item.amount,
          category_id: item.category_id,
          category_name: item.category,
          head_name: item.head_name,
          fee_group_id: item.fee_group_id,
          shift_head: item.shift
        }));
      setSelectedItems((prevSelectedItems) => [
        ...prevSelectedItems,
        ...itemsToAdd,
      ]);
    }
  };

  useEffect(() => {
    if (editFormData.from_month) {
      const selectedMonth = new Date(editFormData.from_month);
      const dueDate = new Date(
        selectedMonth.getFullYear(),
        selectedMonth.getMonth(),
        2
      ); // Set due date to the 5th of the next month
      setEditFormData((prevFormData) => ({
        ...prevFormData,
        due_date: dueDate.toISOString().split("T")[0],
      }));
    }
  }, [editFormData.from_month]);

  const isReadOnly = true; // This can be dynamic

  const classOptions = getClasses.map((classes) => ({
    value: classes.id,
    label: `${classes.class} (${classes.section_name})`,
  }));


  useEffect(() => {
    if (getClasses.length > 0) {
      const allIds = getClasses.map(classes => classes.id);
      const allNames = getClasses.map(classes => `${classes.class} (${classes.section_name})`).join(", ");
      
      setEditFormData(prevState => ({
        ...prevState,
        class_id: allIds,
        class_name: allNames
      }));
    }
  }, [getClasses]);



  function headSet(head){
    setCheckHead(head);
  }


  return (
    <>

{checkHead === 'single_fee_voucher_form' && (
        <>
          <div
            style={{
              position: "fixed",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              zIndex: "100",
              backdropFilter: "blur(10px)",
              width: "100%",
              height: "100%",
              // maxWidth: "1800px",
              // maxHeight: "90vh",
              backgroundColor: "white",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
              padding: "10px",
              // backgroundColor: "#f8f9fa",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                position: "sticky",
                top: 0,
                zIndex: 101,
                backgroundColor: "#EBD197",
                color: "black",
                padding: "8px 16px",
              }}
            >
              <h5 style={{ margin: 0 }}>Single Fee Generate</h5>
              <button
                onClick={() => setCheckHead('')}
                style={{
                  position: "absolute",
                  top: "5px",
                  right: "15px",
                  background: "transparent",
                  border: "none",
                  fontSize: "20px",
                  cursor: "pointer",
                  color: "#ffc107",
                }}
              >
                &times;
              </button>
            </div>

            <div
              style={{
                padding: "20px",
                marginTop: "10px",
                width: "100%",
                overflowY: "auto",
                maxHeight: "calc(90vh - 80px)",
                paddingTop: "5px",
              }}
            >
              <SingleFeeGenerate/>
             
            </div>
          </div>
        </>
      )}



{/*       
{checkHead === 'fee_vouchers_list' && (
        <>
          <div
            style={{
              position: "fixed",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              zIndex: "100",
              backdropFilter: "blur(10px)",
              width: "100%",
              height: "100%",
              // maxWidth: "1800px",
              // maxHeight: "90vh",
              backgroundColor: "white",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
              padding: "10px",
              // backgroundColor: "#f8f9fa",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                position: "sticky",
                top: 0,
                zIndex: 100,
                backgroundColor: "#EBD197",
                color: "black",
                padding: "8px 16px",
              }}
            >
              <h5 style={{ margin: 0 }}>Fee Vouchers List</h5>
              <button
                onClick={() => setCheckHead('')}
                style={{
                  position: "absolute",
                  top: "5px",
                  right: "15px",
                  background: "transparent",
                  border: "none",
                  fontSize: "20px",
                  cursor: "pointer",
                  color: "#ffc107",
                }}
              >
                &times;
              </button>
            </div>

            <div
              style={{
                padding: "20px",
                marginTop: "10px",
                width: "100%",
                overflowY: "auto",
                height:"100%",
                // maxHeight: "calc(90vh - 80px)",
                paddingTop: "5px",
              }}
            >
              <FeeVouchers/>
             
            </div>
          </div>
        </>
      )} */}


      <div className="d-flex">
        <div className="col-md-4 p-2">
          <h5 className="text-warning bg-primary p-2 card-header border">
            <i className="fas fa-file-invoice"></i> Multiple Voucher Generate
          </h5>
          <div className='pt-2 pb-2'><button className='btn btn-sm btn-warning'  onClick={() => headSet('single_fee_voucher_form')} ><i class="fas fa-receipt"></i> Single Fee Generate</button>
          {/* <button className='btn btn-sm btn-warning ml-2'  onClick={() => headSet('fee_vouchers_list')} ><i class="fas fa-list"></i> Fee Vouchers List</button> */}
          </div>
          <form className="border p-3">
            <div className="form-group row">
              <label className="col-sm-2 form-label">Arrear</label>
              <div className="col-sm-4">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="arrear_set"
                    value="true"
                    checked={editFormData.arrear_set === true}
                    onChange={() =>
                      setEditFormData({ ...editFormData, arrear_set: true })
                    }
                  />
                  <label className="form-check-label">Yes</label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="arrear_set"
                    value="false"
                    checked={editFormData.arrear_set === false}
                    onChange={() =>
                      setEditFormData({ ...editFormData, arrear_set: false })
                    }
                  />
                  <label className="form-check-label">No</label>
                </div>
              </div>

              {/* <div className="col-sm-6 text-right">
                <div className="text-primary">
                  <label
                    style={{
                      backgroundColor: "#cce5ff",
                      padding: "5px",
                      borderRadius: "5px",
                    }}
                  >
                    Last Generated:{" "}
                    <a style={{ fontWeight: "bolder" }}>
                      {editFormData.class_name}
                    </a>
                  </label>
                </div>
              </div> */}
            </div>

            <div className="form-group row">
              <label className="col-sm-2 form-label">Bus</label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="bus_fee_status"
                    value="true"
                    checked={editFormData.bus_fee_status === true}
                    onChange={() =>
                      setEditFormData({ ...editFormData, bus_fee_status: true })
                    }
                  />
                  <label className="form-check-label">Yes</label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="bus_fee_status"
                    value="false"
                    checked={editFormData.bus_fee_status === false}
                    onChange={() =>
                      setEditFormData({
                        ...editFormData,
                        bus_fee_status: false,
                      })
                    }
                  />
                  <label className="form-check-label">No</label>
                </div>
              </div>
            </div>

            {/* <div className="form-group row">
                            <label htmlFor="inputEmail3" className="col-sm-2 col-form-label"></label>
                            <div className="col-sm-10 text-right text-primary">
                                <label style={{backgroundColor: '#cce5ff', padding: '5px', borderRadius: '5px'}}>
                                Last Generated Class: <a style={{fontWeight:"bolder"}}>{editFormData.class_name}</a>
                                </label>
                               
                            </div>
                        </div> */}

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Month
              </label>
              <div className="col-sm-10">
                <input
                  type="month"
                  name="amount"
                  value={editFormData.from_month}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      from_month: e.target.value,
                      to_month: e.target.value,
                    });
                    setValidity({ ...validity, from_month: true });
                  }}
                  className={
                    validity.from_month
                      ? "form-control"
                      : "form-control invalid-input"
                  }
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Due.Date
              </label>
              <div className="col-sm-10">
                <input
                  type="date"
                  name="due_date"
                  value={editFormData.due_date}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      due_date: e.target.value,
                    });
                    setValidity({ ...validity, due_date: true });
                  }}
                  className={
                    validity.due_date
                      ? "form-control"
                      : "form-control invalid-input"
                  }
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Fine
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  name="fine"
                  value={editFormData.fine}
                  onChange={(e) => {
                    setEditFormData({ ...editFormData, fine: e.target.value });
                  }}
                  className={"form-control"}
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Remarks
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  name="remarks"
                  value={editFormData.remarks}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      remarks: e.target.value,
                    });
                  }}
                  className={"form-control"}
                />
              </div>
            </div>

            <div className="d-flex justify-content-end">
              
            <button
  type="button"
  className={`btn mb-2 px-3 py-2 shadow-sm text-white fw-bold border-0 ${
    editFormData.class_id.length === getClasses.length
      ? 'bg-primary'
      : 'bg-gradient bg-success'
  }`}
  style={{ transition: 'all 0.3s ease' }}
  onClick={() => {
    const allIds = getClasses.map((cls) => cls.id);
    const allNames = getClasses
      .map((cls) => `${cls.class} (${cls.section_name})`)
      .join(', ');

    if (editFormData.class_id.length === getClasses.length) {
      // Unselect all
      setEditFormData({
        ...editFormData,
        class_id: [],
        class_name: '',
      });
    } else {
      // Select all
      setEditFormData({
        ...editFormData,
        class_id: allIds,
        class_name: allNames,
      });
    }

    setValidity({ ...validity, class_id: true });
  }}
>
  <i
    className={`fas ${
      editFormData.class_id.length === getClasses.length ? 'fa-times-circle' : 'fa-check-circle'
    } me-2`}
  ></i>
  {editFormData.class_id.length === getClasses.length
    ? ' Unselect All Classes'
    : ' Select All Classes'}
</button>

            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Class
              </label>
              <div className="col-sm-10">
                <Select
                  name="class_ids"
                  options={classOptions} // Remove SELECT_ALL_OPTION from options
                  isMulti
                  closeMenuOnSelect={false}
                  hideSelectedOptions={false}
                  components={customComponents}
                  placeholder="Select classes..."
                  value={classOptions.filter((option) =>
                    editFormData.class_id.includes(option.value)
                  )}
                  onChange={(selectedOptions) => {
                    // Remove all logic related to SELECT_ALL_OPTION
                    const filteredOptions = selectedOptions || [];
                    const selectedIds = filteredOptions.map((opt) => opt.value);
                    const selectedNames = filteredOptions
                      .map((opt) => opt.label)
                      .join(", ");

                    setEditFormData({
                      ...editFormData,
                      class_id: selectedIds,
                      class_name: selectedNames,
                    });

                    setValidity({ ...validity, class_id: true });
                  }}
                  className={
                    validity.class_id
                      ? "react-select-container"
                      : "react-select-container invalid-input"
                  }
                  classNamePrefix="react-select"
                />
              </div>
            </div>

            {data.length > 0 && (
              <div className="head-checkbox-container mt-4">
                <h5 className="text-warning font-weight-bold bg-primary p-2">
                  <i className="fas fa-wallet"></i> Select Heads
                </h5>
                {uniqueHeadNames.map((head_name, index) => (
                  <div key={index} className="head-checkbox-item">
                    <label className="head-label font-weight-bold text-primary pt-2">
                      <input
                        type="checkbox"
                        style={{ transform: "scale(1.5)" }}
                        checked={data
                          .filter((item) => item.head_name === head_name)
                          .every((item) =>
                            selectedItems.some(
                              (selected) => selected.id === item.id
                            )
                          )}
                        onChange={() => handleGroupCheckboxChange(head_name)}
                      />
                      &nbsp;&nbsp;&nbsp;{head_name}
                    </label>
                  </div>
                ))}
              </div>
            )}

            <div className="d-flex pt-2 w-100">
              <button
                type="submit"
                className="btn btn-primary btn-block"
                onClick={handleSubmit}
              >
                <i className="fas fa-save" style={{ marginRight: "5px" }}></i>
                Generate Vouchers
              </button>
            </div>
          </form>
        </div>

        <div className="col-md-8 p-2">
          <div className="card-header text-warning bg-primary p-2">
            <div className="d-flex justify-content-between align-items-center">
              <div>
                <i className="fas fa-list"></i> Heads Detail Category Wise
              </div>
              <div className="d-flex">
                <div className="me-2">
                  <input
                    type="text"
                    className="form-control"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onKeyDown={handleKeyDown}
                  />
                </div>
                <button
                  className="btn btn-sm btn-danger ml-2"
                  onClick={handleSearch}
                >
                  Search
                </button>
              </div>
            </div>
          </div>

          <div className="border p-2">
            <table className="table">
              <thead>
                <tr>
                  <th>Group</th>
                  <th>Head</th>
                  <th>Category</th>
                   <th>Shift</th>
                  <th>Amount</th>
                  <th className="text-center">Active</th>
                </tr>
              </thead>
              <tbody>
                {currentItems.map((head_detail, index) => (
                  <tr key={index}>
                    <td>{head_detail.fee_group_name}</td>
                    <td>{head_detail.head_name}</td>
                    <td>{head_detail.category}</td>
                    <td>{head_detail.shift}</td>
                    <td>{head_detail.amount}</td>
                    <td className="text-center">
                      <div>
                        {/* <input
                                                    type="checkbox"
                                                    id={`head_detail_${head_detail.id}`}
                                                    checked={selectedItems.some(item => item.id === head_detail.id)}
                                                    onChange={() => handleCheckboxChange(
                                                        head_detail.id,
                                                        head_detail.amount,
                                                        head_detail.category_id,
                                                        head_detail.category,
                                                        head_detail.head_name
                                                    )}
                                                /> */}

                        <input
                          type="checkbox"
                          readOnly
                          style={{ transform: "scale(1.5)" }}
                          id={`head_detail_${head_detail.id}`}
                          checked={selectedItems.some(
                            (item) => item.id === head_detail.id
                          )}
                          onClick={(event) => {
                            if (isReadOnly) {
                              event.preventDefault(); // Prevent change for read-only checkboxes
                            }
                          }}
                          onChange={() => {
                            if (!isReadOnly) {
                              handleCheckboxChange(
                                head_detail.id,
                                head_detail.amount,
                                head_detail.category_id,
                                head_detail.category,
                                head_detail.head_name
                              );
                            }
                          }}
                        />
                      </div>
                    </td>
                  </tr>
                ))}
                {/* <tr>
                                    <td style={{ textAlign: "right" }} colSpan={"4"}>
                                        <input
                                            type="submit"
                                            className='btn btn-sm btn-primary'
                                            value={"Save"}
                                            onClick={handleSubmit}
                                        />
                                    </td>
                                </tr> */}
              </tbody>
            </table>
          </div>

          <ReactPaginate
            previousLabel={"Previous"}
            nextLabel={"Next"}
            breakLabel={"..."}
            pageCount={pageCount}
            marginPagesDisplayed={2}
            pageRangeDisplayed={5}
            onPageChange={handlePageClick}
            containerClassName={"pagination"}
            activeClassName={"active"}
            pageClassName={"page-item"}
            pageLinkClassName={"page-link"}
            previousClassName={"page-item"}
            previousLinkClassName={"page-link"}
            nextClassName={"page-item"}
            nextLinkClassName={"page-link"}
            breakClassName={"page-item"}
            breakLinkClassName={"page-link"}
          />
        </div>
      </div>
    </>
  );
}

export default FeeGenerate;







