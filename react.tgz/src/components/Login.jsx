
// src/components/Login.js
import React, { useState } from 'react';
import authService from './services/authService';
import { useAuth } from './AuthContext';
import { Link, useNavigate } from 'react-router-dom';
// import { FaUser, FaLock } from 'react-icons/fa';
// import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
import '../App.css'; // Create and import a CSS file for styling
import SessionNavbar from './SessionNavbar';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = () => {
    authService.login(username, password)
      .then(response => {
        login(response);
        var user_name = localStorage.getItem('username');
        <SessionNavbar  user={user_name}  />
        navigate("/");    
      })
      .catch(error => {
        console.log("logout successfully");
        // toast.error('Login failed');
      });
  };

  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", width:"100vw", height:"100vh" }}>
    <div className="login-container">
    <div><h4 style={{color: "white", fontWeight:"bolder"}}>Welcome to <br/> Sir Syed Educational Institutes</h4></div>
       <div className='pb-5 pt-3'>
       <img 
        style={{ width: '150px' }} 
        src={`${process.env.REACT_APP_BASE_URL}/uploads/logo.png`} 
        alt="Logo" 
      />

      </div>
      <div className="input-container">
        {/* <FaUser /> */}
        <input
          type="text"
          placeholder="Type your username"
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>
      <div className="input-container">
        {/* <FaLock /> */}
        <input
          type="password"
          placeholder="Type your password"
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <button onClick={handleLogin} className="btn btn-sm btn-warning">LOGIN</button>
      <div>
        <div style={{"marginTop" : "20px", "color" : "white"}}><h5>©2025 ERP Campus Management System DEVELOPED BY SSES(IT)</h5></div>
      {/* <label className='mt-5'><Link to="/register-sses-user"  style={{color:'black'}}>for registeration click here?</Link></label> */}
      </div>
      {/* <div className="social-login">
        <p>Or Sign Up Using</p>
        <div className="social-icons">
          <a href="#"><i className="fab fa-facebook-f"></i></a>
          <a href="#"><i className="fab fa-twitter"></i></a>
          <a href="#"><i className="fab fa-google"></i></a>
        </div>
      </div> */}
      {/* <div className="sign-up">
        <p>Or Sign Up Using</p>
        <a href="#">SIGN UP</a>
      </div> */}
      {/* <ToastContainer /> */}
    </div>
    
    </div>
  );
};

export default Login;


