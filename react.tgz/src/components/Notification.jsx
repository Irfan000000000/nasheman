import React, { useCallback, useContext, useEffect, useState, useMemo } from "react";
import axios from "axios";
import Select from "react-select";
import { useDropzone } from "react-dropzone";
import { useAuth } from "./AuthContext";
import AcademicSessionContext from "./AcademicSessionContext";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";
import ReactPaginate from "react-paginate";

function Notification() {
  const { user } = useAuth();
  const { academicSession } = useContext(AcademicSessionContext);

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [isEditMode, setIsEditMode] = useState(false);
  const [showData, setShowData] = useState("");
  const [totalItem, setTotalItem] = useState(10);
  const [fileName, setFileName] = useState("");
  const [filePreview, setFilePreview] = useState(null);
  const [searchCategoryReport, setSearchCategoryReport] = useState({ search: "" });

  const typeOptions = [
    { value: "News", label: "📰 News" },
    { value: "Event", label: "📅 Event" },
    { value: "Notification", label: "🔔 Notification" },
  ];

  const styles = {
    container: {
      fontFamily: 'Arial, sans-serif',
      padding: '20px',
      backgroundColor: '#f5f5f5',
      minHeight: '100vh'
    },
    mainCard: {
      maxWidth: '900px',
      margin: '0 auto',
      backgroundColor: '#fff',
      borderRadius: '8px',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      overflow: 'hidden'
    },
    header: {
      backgroundColor: '#2c3e50',
      color: '#ffc107',
      padding: '15px 20px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    },
    headerTitle: {
      margin: 0,
      fontSize: '18px',
      fontWeight: 'bold',
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    },
    button: {
      backgroundColor: '#ffc107',
      color: '#000',
      border: 'none',
      padding: '8px 16px',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '500',
      transition: 'all 0.3s ease'
    },
    buttonDanger: { backgroundColor: '#dc3545', color: '#fff' },
    buttonSuccess: { backgroundColor: '#28a745', color: '#fff' },
    buttonPrimary: { backgroundColor: '#007bff', color: '#fff' },
    buttonSecondary: { backgroundColor: '#6c757d', color: '#fff' },
    formContainer: { padding: '20px' },
    formGroup: { flex: 1, marginBottom: '20px' },
    label: {
      display: 'block',
      marginBottom: '8px',
      fontWeight: '500',
      color: '#333',
      fontSize: '14px'
    },
    input: {
      width: '100%',
      padding: '10px',
      border: '1px solid #ddd',
      borderRadius: '4px',
      fontSize: '14px',
      boxSizing: 'border-box'
    },
    inputInvalid: { borderColor: '#dc3545' },
    errorText: { color: '#dc3545', fontSize: '12px', marginTop: '4px' },
    dropzone: {
      border: '2px dashed #ddd',
      borderRadius: '4px',
      padding: '30px 20px',
      textAlign: 'center',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      backgroundColor: '#fafafa'
    },
    modal: {
      position: 'fixed',
      top: 0, left: 0, right: 0, bottom: 0,
      backgroundColor: 'rgba(0,0,0,0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '20px',
      overflowY: 'auto'
    },
    modalContent: {
      backgroundColor: '#fff',
      borderRadius: '8px',
      width: '95%',
      maxWidth: '1400px',
      maxHeight: '90vh',
      overflow: 'hidden',
      boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
      display: 'flex',
      flexDirection: 'column'
    },
    modalHeader: {
      backgroundColor: '#2c3e50',
      color: '#ffc107',
      padding: '15px 20px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    },
    modalBody: { padding: '20px', overflowY: 'auto', flex: 1 },
    closeButton: {
      backgroundColor: 'transparent',
      border: 'none',
      color: '#fff',
      cursor: 'pointer',
      fontSize: '28px',
      lineHeight: '1',
      padding: '0',
      width: '30px',
      height: '30px'
    },
    table: {
      width: '100%',
      borderCollapse: 'collapse',
      backgroundColor: '#fff',
      marginTop: '20px'
    },
    th: {
      backgroundColor: '#2c3e50',
      color: '#ffc107',
      padding: '12px',
      textAlign: 'left',
      fontWeight: 'bold',
      fontSize: '14px',
      borderRight: '1px solid #444'
    },
    td: {
      padding: '12px',
      borderBottom: '1px solid #ddd',
      fontSize: '14px',
      verticalAlign: 'top'
    },
    buttonGroup: {
      display: 'flex',
      gap: '8px',
      justifyContent: 'flex-end',
      marginTop: '20px'
    },
    searchContainer: {
      display: 'flex',
      gap: '10px',
      alignItems: 'center',
      flexWrap: 'wrap',
      marginBottom: '20px'
    },
    actionButtons: { display: 'flex', gap: '8px' },
    iconButton: {
      padding: '6px 12px',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '14px',
      transition: 'all 0.3s ease'
    },
    badge: {
      display: 'inline-block',
      padding: '3px 10px',
      borderRadius: '12px',
      fontSize: '12px',
      fontWeight: 'bold',
      color: '#fff'
    }
  };

  const initialState = {
    hidden_id: "",
    title: "",
    type: "",
    description: "",
    start_date: "",
    end_date: "",
    session_id: academicSession,
    campus_id: user?.user?.campus_id,
    created_by: user?.user?.student_unique_id,
    notification_file: null,
    current_file: "",
    is_active: 1,
  };

  const [formData, setFormData] = useState(initialState);

  const [validity, setValidity] = useState({
    title: true,
    type: true,
    description: true,
    start_date: true,
  });

  const modules = useMemo(() => ({
    toolbar: [
      [{ header: [1, 2, 3, false] }],
      ["bold", "italic", "underline", "strike"],
      [{ list: "ordered" }, { list: "bullet" }],
      ["link"],
      ["clean"],
    ],
  }), []);

  const formats = ["header", "bold", "italic", "underline", "strike", "list", "bullet", "link"];

  useEffect(() => {
    if (academicSession) {
      setFormData((prev) => ({ ...prev, session_id: parseInt(academicSession) }));
    }
  }, [academicSession]);

  useEffect(() => {
    fetchData();
  }, [currentPage, totalItem]);

  const onDrop = useCallback((acceptedFiles, rejectedFiles) => {
    if (rejectedFiles && rejectedFiles.length > 0) {
      const err = rejectedFiles[0].errors[0];
      if (err?.code === 'file-too-large') toast.error("File size must be less than 10MB");
      else if (err?.code === 'file-invalid-type') toast.error("Invalid file type");
      else toast.error("File upload failed");
      return;
    }
    const file = acceptedFiles[0];
    if (file.size > 10 * 1024 * 1024) { toast.error("File size must be less than 10MB"); return; }
    setFileName(file.name);
    setFormData((prev) => ({ ...prev, notification_file: file }));
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => setFilePreview(reader.result);
      reader.readAsDataURL(file);
    } else {
      setFilePreview(null);
    }
  }, [formData]);

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'text/plain': ['.txt']
    },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setValidity((prev) => ({ ...prev, [name]: true }));
  };

  const handleTypeChange = (selectedOption) => {
    setFormData((prev) => ({ ...prev, type: selectedOption?.value || "" }));
    setValidity((prev) => ({ ...prev, type: true }));
  };

  const handleDescriptionChange = (value) => {
    setFormData((prev) => ({ ...prev, description: value }));
    setValidity((prev) => ({ ...prev, description: true }));
  };

  const validateForm = () => {
    let isValid = true;
    const newValidity = { title: true, type: true, description: true, start_date: true };

    if (!formData.title.trim()) { newValidity.title = false; isValid = false; }
    if (!formData.type) { newValidity.type = false; isValid = false; }
    if (!formData.description || formData.description.trim() === "<p><br></p>") { newValidity.description = false; isValid = false; }
    if (!formData.start_date.trim()) { newValidity.start_date = false; isValid = false; }

    setValidity(newValidity);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) { toast.error("Please fill all required fields"); return; }

    const fd = new FormData();
    for (const key in formData) { fd.append(key, formData[key]); }

    try {
      const url = isEditMode
        ? process.env.REACT_APP_API_BASE_URL + `/update-notification/${formData.hidden_id}`
        : process.env.REACT_APP_API_BASE_URL + "/insert-notification";
      const method = isEditMode ? "put" : "post";
      const response = await axios[method](url, fd, { headers: { "Content-Type": "multipart/form-data" } });

      if (response.data.error) {
        toast.error(response.data.error);
      } else {
        toast.success(`Notification ${isEditMode ? "updated" : "added"} successfully!`);
        resetForm();
        fetchData();
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error(`Failed to ${isEditMode ? "update" : "add"} notification.`);
    }
  };

  const resetForm = () => {
    setFormData({ ...initialState, session_id: academicSession, campus_id: user?.user?.campus_id, created_by: user?.user?.student_unique_id });
    setFilePreview(null);
    setFileName("");
    setIsEditMode(false);
  };

  const fetchData = () => {
    axios.get(process.env.REACT_APP_API_BASE_URL + "/notification-list", {
      params: {
        page: currentPage,
        limit: totalItem,
        search: searchCategoryReport.search,
        campus_id: user?.user?.campus_id,
        session_id: academicSession,
      },
    })
    .then((res) => {
      setData(res.data.data);
      setTotalPages(res.data.totalPages);
      setLoading(false);
    })
    .catch((err) => { console.log(err); setLoading(false); });
  };

  const handlePageChange = ({ selected }) => setCurrentPage(selected + 1);
  const handleTotalItemChange = (e) => setTotalItem(e.target.value);
  const handleKeyDown = (e) => { if (e.key === "Enter") fetchData(); };

  const handleDelete = (id) => {
    if (!window.confirm("Are you sure you want to delete?")) return;
    axios.delete(process.env.REACT_APP_API_BASE_URL + `/delete-notification/${id}/${user?.user?.campus_id}`)
      .then(() => {
        setData((prev) => prev.filter((d) => d.id !== id));
        toast.error("Notification deleted successfully");
      })
      .catch((err) => console.error("Error deleting:", err));
  };

  const editNotification = (id) => {
    axios.get(process.env.REACT_APP_API_BASE_URL + `/get-notification/${id}/${user?.user?.campus_id}`)
      .then((response) => {
        const item = response.data.results[0];
        const formatDate = (d) => {
          if (!d) return "";
          const date = new Date(d);
          return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
        };
        setFormData({
          hidden_id: item.id,
          title: item.title,
          type: item.type,
          description: item.description,
          start_date: formatDate(item.start_date),
          end_date: formatDate(item.end_date),
          session_id: academicSession,
          campus_id: user?.user?.campus_id,
          created_by: user?.user?.student_unique_id,
          notification_file: null,
          current_file: item.notification_file || "",
          is_active: item.is_active,
        });
        setFileName(item.notification_file ? item.notification_file.split("/").pop() : "");
        setIsEditMode(true);
        setShowData("");
      })
      .catch((err) => console.error("Error fetching notification:", err));
  };

  const handleDownload = async (fileName) => {
    try {
      const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/uploads/${fileName}`);
      if (!response.ok) throw new Error('File not found');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast.success('File downloaded successfully');
    } catch (error) {
      toast.error('Failed to download file');
    }
  };

  const getBadgeColor = (type) => {
    if (type === "News") return "#17a2b8";
    if (type === "Event") return "#6f42c1";
    return "#ffc107";
  };

  return (
    <div style={styles.container}>
      <div style={styles.mainCard}>
        {/* Header */}
        <div style={styles.header}>
          <h5 style={styles.headerTitle}>
            <i className="fas fa-bell"></i>
            {isEditMode ? "Edit Notification" : "Add Notification / News / Event"}
          </h5>
          <button
            style={styles.button}
            onClick={() => setShowData("view_notification_list")}
            onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#ffb300'}
            onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#ffc107'}
          >
            <i className="fas fa-eye"></i> View List
          </button>
        </div>

        {/* Form */}
        <form style={styles.formContainer} onSubmit={handleSubmit}>
          <input type="hidden" name="hidden_id" value={formData.hidden_id} />
          <input type="hidden" name="current_file" value={formData.current_file} />

          {/* Title */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Title *</label>
            <input
              type="text"
              name="title"
              placeholder="Enter title..."
              style={{ ...styles.input, ...(validity.title ? {} : styles.inputInvalid) }}
              value={formData.title}
              onChange={handleChange}
            />
            {!validity.title && <div style={styles.errorText}>Please enter a title</div>}
          </div>

          {/* Type */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Type *</label>
            <Select
              options={typeOptions}
              value={typeOptions.find((o) => o.value === formData.type) || null}
              onChange={handleTypeChange}
              placeholder="Select Type (News / Event / Notification)"
              styles={{
                control: (base) => ({
                  ...base,
                  borderColor: validity.type ? '#ddd' : '#dc3545'
                })
              }}
            />
            {!validity.type && <div style={styles.errorText}>Please select a type</div>}
          </div>

          {/* Dates Row */}
          <div style={{ display: 'flex', gap: '15px' }}>
            <div style={{ ...styles.formGroup, flex: 1 }}>
              <label style={styles.label}>Start Date *</label>
              <input
                type="date"
                name="start_date"
                style={{ ...styles.input, ...(validity.start_date ? {} : styles.inputInvalid) }}
                value={formData.start_date}
                onChange={handleChange}
              />
              {!validity.start_date && <div style={styles.errorText}>Please select a start date</div>}
            </div>
            <div style={{ ...styles.formGroup, flex: 1 }}>
              <label style={styles.label}>End Date <span style={{ color: '#999', fontWeight: 'normal' }}>(Optional)</span></label>
              <input
                type="date"
                name="end_date"
                style={styles.input}
                value={formData.end_date}
                onChange={handleChange}
              />
            </div>
          </div>

          {/* Description */}
          <div style={styles.formGroup}>
            <label style={styles.label}>Description *</label>
            <ReactQuill
              theme="snow"
              value={formData.description}
              onChange={handleDescriptionChange}
              modules={modules}
              formats={formats}
              placeholder="Enter details..."
            />
            {!validity.description && <div style={styles.errorText}>Please enter a description</div>}
          </div>

          {/* File Upload */}
          <div style={styles.formGroup}>
            <label style={styles.label}>
              {isEditMode ? "Update File" : "Attach File"} <span style={{ color: '#999', fontWeight: 'normal' }}>(Optional, Max 10MB)</span>
            </label>
            <div
              {...getRootProps()}
              style={styles.dropzone}
              onMouseOver={(e) => e.currentTarget.style.borderColor = '#007bff'}
              onMouseOut={(e) => e.currentTarget.style.borderColor = '#ddd'}
            >
              <input {...getInputProps()} />
              {filePreview && formData.notification_file?.type?.startsWith('image/') ? (
                <div>
                  <img src={filePreview} alt="Preview" style={{ maxWidth: '200px', maxHeight: '200px', marginBottom: '10px' }} />
                  <p style={{ margin: 0, color: '#28a745', fontWeight: '500' }}>
                    <i className="fas fa-file-image"></i> {fileName}
                  </p>
                </div>
              ) : fileName ? (
                <p style={{ margin: 0, color: '#007bff', fontWeight: '500' }}>
                  <i className="fas fa-file"></i> {fileName}
                </p>
              ) : (
                <div>
                  <p style={{ margin: 0, color: '#666', marginBottom: '8px' }}>
                    <i className="fas fa-cloud-upload-alt"></i> Drag & drop a file here, or click to select
                  </p>
                  <p style={{ margin: 0, fontSize: '12px', color: '#999' }}>
                    Allowed: Images, PDF, Word, Excel (Max 10MB)
                  </p>
                </div>
              )}
            </div>
            {isEditMode && (
              <div style={{ fontSize: '12px', color: '#666', marginTop: '8px' }}>
                Leave empty to keep current file
              </div>
            )}
          </div>

          {/* Status (Edit mode only) */}
          {isEditMode && (
            <div style={styles.formGroup}>
              <label style={styles.label}>Status</label>
              <select
                name="is_active"
                value={formData.is_active}
                onChange={handleChange}
                style={{ ...styles.input, width: 'auto' }}
              >
                <option value={1}>Active</option>
                <option value={0}>Inactive</option>
              </select>
            </div>
          )}

          {/* Buttons */}
          <div style={styles.buttonGroup}>
            {isEditMode && (
              <button
                type="button"
                style={{ ...styles.button, ...styles.buttonSecondary }}
                onClick={resetForm}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#5a6268'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#6c757d'}
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              style={{ ...styles.button, ...styles.buttonPrimary }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#0056b3'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#007bff'}
            >
              {isEditMode ? "Update" : "Submit"}
            </button>
          </div>
        </form>
      </div>

      {/* List Modal */}
      {showData === "view_notification_list" && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <div style={styles.modalHeader}>
              <h2 style={{ margin: 0, fontSize: '18px', fontWeight: 'bold' }}>
                <i className="fas fa-bell"></i> Notification / News / Event List
              </h2>
              <button style={styles.closeButton} onClick={() => setShowData("")}>×</button>
            </div>

            <div style={styles.modalBody}>
              <div style={styles.searchContainer}>
                <input
                  type="text"
                  style={styles.input}
                  placeholder="Search..."
                  onKeyDown={handleKeyDown}
                  onChange={(e) => setSearchCategoryReport({ search: e.target.value })}
                />
                <button
                  style={{ ...styles.button, ...styles.buttonDanger }}
                  onClick={fetchData}
                  onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#c82333'}
                  onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc3545'}
                >
                  <i className="fas fa-search"></i> Search
                </button>
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label style={{ marginRight: '10px', fontSize: '14px' }}>Show: </label>
                <select
                  value={totalItem}
                  onChange={handleTotalItemChange}
                  style={{ ...styles.input, width: 'auto', display: 'inline-block', padding: '6px 12px' }}
                >
                  <option value="10">10</option>
                  <option value="20">20</option>
                  <option value="30">30</option>
                  <option value="50">50</option>
                </select>
              </div>

              <table style={styles.table}>
                <thead>
                  <tr>
                    <th style={styles.th}>#</th>
                    <th style={styles.th}>Type</th>
                    <th style={styles.th}>Title</th>
                    <th style={styles.th}>Start Date</th>
                    <th style={styles.th}>End Date</th>
                    <th style={styles.th}>Description</th>
                    <th style={styles.th}>File</th>
                    <th style={styles.th}>Status</th>
                    <th style={styles.th}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="9" style={{ ...styles.td, textAlign: 'center' }}>Loading...</td>
                    </tr>
                  ) : data.length === 0 ? (
                    <tr>
                      <td colSpan="9" style={{ ...styles.td, textAlign: 'center' }}>No records found</td>
                    </tr>
                  ) : (
                    data.map((item, index) => (
                      <tr key={index}>
                        <td style={styles.td}>{(currentPage - 1) * totalItem + index + 1}</td>
                        <td style={styles.td}>
                          <span style={{ ...styles.badge, backgroundColor: getBadgeColor(item.type) }}>
                            {item.type}
                          </span>
                        </td>
                        <td style={styles.td}>{item.title}</td>
                        <td style={styles.td}>{item.start_date}</td>
                        <td style={styles.td}>{item.end_date || "-"}</td>
                        <td style={styles.td} dangerouslySetInnerHTML={{ __html: item.description }}></td>
                        <td style={styles.td}>
                          {item.notification_file ? (
                            <button
                              type="button"
                              onClick={() => handleDownload(item.notification_file)}
                              style={{ ...styles.button, ...styles.buttonSuccess, border: 'none', cursor: 'pointer', padding: '6px 12px' }}
                              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#218838'}
                              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#28a745'}
                            >
                              <i className="fas fa-download"></i>
                            </button>
                          ) : (
                            <span style={{ color: '#999' }}>No file</span>
                          )}
                        </td>
                        <td style={styles.td}>
                          <span style={{
                            ...styles.badge,
                            backgroundColor: item.is_active == 1 ? '#28a745' : '#dc3545'
                          }}>
                            {item.is_active == 1 ? "Active" : "Inactive"}
                          </span>
                        </td>
                        <td style={styles.td}>
                          <div style={styles.actionButtons}>
                            <button
                              style={{ ...styles.iconButton, ...styles.buttonPrimary }}
                              onClick={() => editNotification(item.id)}
                              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#0056b3'}
                              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#007bff'}
                            >
                              <i className="fas fa-edit"></i>
                            </button>
                            <button
                              style={{ ...styles.iconButton, ...styles.buttonDanger }}
                              onClick={() => handleDelete(item.id)}
                              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#c82333'}
                              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#dc3545'}
                            >
                              <i className="fas fa-trash-alt"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              <div style={{ marginTop: '20px' }}>
                <ReactPaginate
                  previousLabel={"Previous"}
                  nextLabel={"Next"}
                  breakLabel={"..."}
                  pageCount={totalPages}
                  marginPagesDisplayed={2}
                  pageRangeDisplayed={3}
                  onPageChange={handlePageChange}
                  containerClassName={"pagination"}
                  pageClassName={"page-item"}
                  activeClassName={"active"}
                  pageLinkClassName={"page-link"}
                  previousClassName={"page-item"}
                  previousLinkClassName={"page-link"}
                  nextClassName={"page-item"}
                  nextLinkClassName={"page-link"}
                  breakClassName={"page-item"}
                  breakLinkClassName={"page-link"}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Notification;