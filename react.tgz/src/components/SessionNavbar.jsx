


// import React, { useContext, useEffect, useState } from 'react';
// import { useAuth } from './AuthContext';
// import { useSessions } from './SessionContext';
// import AcademicSessionContext from './AcademicSessionContext'; // Import the ClassSessionContext if needed

// export default function SessionNavbar() {
//   const { user } = useAuth(); // Use the useAuth hook to get the user
//   const { getSessions } = useSessions(); // Use the useSessions hook to get the sessions
//   const [isMounted, setIsMounted] = useState(false); // State to track if the component is mounted
//   const { academicSession, setAcademicSession, classSession, setClassSession } =useContext(AcademicSessionContext); // Replace with your actual context values

//   // const { classSession, setClassSession } = useContext(ClassSessionContext); // Replace with your actual context values

//   useEffect(() => {
//     setIsMounted(true); // Set the component as mounted
//   }, []);

//   useEffect(() => {
//     if (isMounted) {
//       const userName = user ? user.user.username : ""; // Get the user name from context
//       const user_id = user ? user.user.user_id : "";
//       const campus_name = user ? user.user.campus_name : ""; // Get the user name from context
//       const campus_id = user ? user.user.campus_id : ""; // Get the user name from context
//       const campus_code = user ? user.user.campus_code : ""; // Get campus code from context

//       console.log("Fetched user name from context:", userName);
//     }
//   }, [isMounted, user]); // Run this effect only when the component is mounted and user changes

//   useEffect(() => {

//     // console.log(getSessions);
//     // Set academicSession to the first session with status "On" by default
//     const defaultSession = getSessions.find(
//       (session) => session.status === "On"
//     );
//     if (defaultSession) {
//       setAcademicSession(defaultSession.id);
//     }
//   }, [getSessions, setAcademicSession]);

//   return (
//     <>
//       <div className="row pl-4">
//         <div className="col-md-2 col-sm-12 mt-2  mr-3">
//           <input
//             type="text"
//             className="form-control"
//             readOnly
//             id="user_name"
//             value={user ? user.user.username : ""} // Display the user name
//           />
//         </div>

//         <div className="col-md-2  col-sm-12 mr-3 mt-2">
//           <input
//             type="text"
//             className="form-control"
//             readOnly
//             id="user_name"
//             value={user ? user.user.campus_name : ""} // Display the user name
//           />
//         </div>

//         {/* {user && user.user.user_type !== "Student" && ( */}
//           <div className="col-md-2  col-sm-12  mt-2 mr-3">
//             <select
//               name="session_id"
//               id="session_id"
//               className="form-control"
//               value={academicSession} // Use academicSession from context
//               onChange={(e) => setAcademicSession(e.target.value)}
//               style={{ marginRight: "20px" }}
//             >
//               <option value="">Select Session</option>
//               {getSessions.map((session) => (
//                 <option key={session.id} value={session.id}>
//                   {session.session_name}
//                 </option>
//               ))}
//             </select>
//           </div>
//         {/* )} */}
        
//       </div>
//     </>
//   );
// }



import React, { useContext, useEffect, useState } from 'react';
import { useAuth } from './AuthContext';
import { useSessions } from './SessionContext';
import AcademicSessionContext from './AcademicSessionContext';

export default function SessionNavbar() {
  const { user } = useAuth();
  const { getSessions } = useSessions();
  const [isMounted, setIsMounted] = useState(false);
  const { academicSession, setAcademicSession } = useContext(AcademicSessionContext);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (isMounted) {
      const userName = user ? user.user.username : "";
      const campus_name = user ? user.user.campus_name : "";
      console.log("Fetched user name from context:", userName);
    }
  }, [isMounted, user]);

  useEffect(() => {
    const defaultSession = getSessions.find((session) => session.status === "On");
    if (defaultSession) {
      setAcademicSession(defaultSession.id);
    }
  }, [getSessions, setAcademicSession]);

  return (
    <div className="session-navbar-container">
      <div className="row align-items-center">
        {/* User Name Input */}
        <div className="col-md-3 col-sm-12 mt-2">
          <div className="input-group">
            <div className="input-group-prepend">
              <span className="input-group-text">
                <i className="fas fa-user"></i>
              </span>
            </div>
            <input
              type="text"
              className="form-control session-input"
              readOnly
              id="user_name"
              value={user ? user.user.username : ""}
              placeholder="User Name"
            />
          </div>
        </div>

        {/* Campus Name Input */}
        <div className="col-md-3 col-sm-12 mt-2">
          <div className="input-group">
            <div className="input-group-prepend">
              <span className="input-group-text">
                <i className="fas fa-school"></i>
              </span>
            </div>
            <input
              type="text"
              className="form-control session-input"
              readOnly
              id="campus_name"
              value={user ? user.user.campus_name : ""}
              placeholder="Campus Name"
            />
          </div>
        </div>

        {/* Session Dropdown */}
        <div className="col-md-3 col-sm-12 mt-2">
          <div className="input-group">
            <div className="input-group-prepend">
              <span className="input-group-text">
                <i className="fas fa-calendar-alt"></i>
              </span>
            </div>
            <select
              name="session_id"
              id="session_id"
              className="form-control session-select"
              value={academicSession}
              onChange={(e) => setAcademicSession(e.target.value)}
            >
              <option value="">Select Session</option>
              {getSessions.map((session) => (
                <option key={session.id} value={session.id}>
                  {session.session_name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}