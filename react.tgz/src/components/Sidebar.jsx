// import React, { useState } from 'react';
// import '../Sidebar.css';
// import authService from './services/authService';
// import { Link } from 'react-router-dom';
// import { useAuth } from './AuthContext';





// const Sidebar = () => {
//   const [dropdowns, setDropdowns] = useState({
//     admission: false,
//     attendance: false,
//     exam: false,
//     fee: false
//   });

//   const [isSidebarVisible, setIsSidebarVisible] = useState(false);

//   const { user } = useAuth();

//   const toggleDropdown = (name) => {
//     setDropdowns(prevState => {
//       const newState = {
//         admission: false,
//         attendance: false,
//         exam: false,
//         fee: false,
//       };
//       newState[name] = !prevState[name];
//       return newState;
//     });
//   };

//   const toggleSidebar = () => {
//     setIsSidebarVisible(!isSidebarVisible);
//   };



//   const handleLogout = () => {
//     authService.logout();
//     window.location.reload();
//   };



//   return (
//     <>
//       <div className={`sidebar ${isSidebarVisible ? 'show' : 'hide'} ${user.user.user_type == 'Student' || user.user.user_type == 'Teacher' ? 'd-none' : ''}`}>

//         <h4 className='p-2 text-center' style={{background:'#EBD197'}}> <Link to="/" className="dropdown-item" style={{color:'black', fontWeight: 'bolder'}}>Dashboard</Link></h4>
        
//         {user && user.user.user_type =='Admin' && (
//         <div className='pl-3'>
//           <div className="sidebar-item" onClick={() => toggleDropdown('admission')}>
//             <i className="fas fa-graduation-cap"></i>
//             <a href="#">Student Information</a>
//             <i className={`icon-arrow ${dropdowns.admission ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.admission && (
//             <div className="dropdown">
//               <Link to="/admission-form" className="dropdown-item">Create Admission</Link>
//               <Link to="/promote-students" className="dropdown-item">Promote Students</Link>
//               <Link to="/admission-list" className="dropdown-item">Admission List</Link>
//               <Link to="/create-class" className="dropdown-item">Create Class</Link>
//               <Link to="/create-section" className="dropdown-item">Create Section</Link>
//               <Link to="/create-fee-group" className="dropdown-item">Create Fee Group</Link>
//               <Link to="/select-categories" className="dropdown-item">Create Categories</Link>
//               <Link to="/student-id-card-generate" className="dropdown-item">Student ID Card</Link>
//               <Link to="/student-accounts" className="dropdown-item">Student Accounts</Link>
//               <Link to="/create-house-and-club" className="dropdown-item">Create House/Club</Link>
//             </div>
//           )}

//           <div className="sidebar-item" onClick={() => toggleDropdown('attendance')}>
//             <i className="fas fa-chalkboard-teacher"></i>
//             <a href="#">Attendance</a>
//             <i className={`icon-arrow ${dropdowns.attendance ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.attendance && (
//             <div className="dropdown">
//               <Link to="/student-attendance-list" className="dropdown-item">Student Attendance</Link>
//               <Link to="/attendance-list" className="dropdown-item">Employee Attendance</Link>
//             </div>
//           )}

//           <div className="sidebar-item" onClick={() => toggleDropdown('exam')}>
//             <i className="fas fa-book"></i>
//             <a href="#">Exam</a>
//             <i className={`icon-arrow ${dropdowns.exam ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.exam && (
//             <div className="dropdown">
//               <a href="#" className="dropdown-item">Create Exam</a>
//               <a href="#" className="dropdown-item">Add Marks</a>
//               <a href="#" className="dropdown-item">Exam Report</a>
//             </div>
//           )}

//           <div className="sidebar-item" onClick={() => toggleDropdown('fee')}>
//             <i className="fas fa-receipt"></i>
//             <a href="#">Fee</a>
//             <i className={`icon-arrow ${dropdowns.fee ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.fee && (
//             <div className="dropdown">
//               <Link to="/bank-details-form" className="dropdown-item">Bank Detail</Link>
//               <Link to="/bank-notes" className="dropdown-item">Voucher Notes</Link>
//               {/* <Link to="/fee-fine" className="dropdown-item">Fee Fine</Link> */}
//               {/* <a href="#" className="dropdown-item">Bank Branch</a> */}
//               <Link to="/heads" className="dropdown-item">Fee Head</Link>
//               <Link to="/fee-head-details" className="dropdown-item">Fee Head Details</Link>
//               <Link to="/fee-generate" className="dropdown-item">Fee Generate</Link>
//               {/* <Link to="/single-fee-generate" className="dropdown-item">Single Fee Generate</Link> */}
//               {/* <Link to="/edit-fee-voucher" className="dropdown-item">Edit Fee Voucher</Link> */}
//               <Link to="/fee-vouchers" className="dropdown-item">Fee Vouchers</Link>
//               <Link to="/fee-post" className="dropdown-item">Fee Post</Link>
//               <Link to="/fee-post-all" className="dropdown-item">Fee Post All</Link>
//               <Link to="/fee-reports" className="dropdown-item">Fee Reports</Link>
//             </div>
//           )}


//           <div className="sidebar-item" onClick={() => toggleDropdown('hr')}>
//             <i className="fas fa-users"></i>
//             <a href="#">HR</a>
//             <i className={`icon-arrow ${dropdowns.hr ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.hr && (
//             <div className="dropdown">
//               <Link to="/employee-form" className="dropdown-item">Add Employee</Link>
//               <Link to="/employee-list" className="dropdown-item">Employee List</Link>
//               <Link to="/employee-id-card-generate" className="dropdown-item">Employee ID Card</Link>
//               {/* <Link to="/pay-scale-wise-basic-salary" className="dropdown-item">Create Basic Salary</Link> */}
//               <Link to="/increments-pay-scale-wise" className="dropdown-item">Increments</Link>
//               <Link to="/overtime" className="dropdown-item">Overtime</Link>
//               <Link to="/salary-of-employee" className="dropdown-item">Generate Salary</Link>
//               <Link to="/school-salary-list" className="dropdown-item">Salary List</Link>
//                <Link to="/employee-discipline-form" className="dropdown-item">Employee Discipline</Link>
//               <Link to="/salary-reports" className="dropdown-item">Salary Report</Link>
//             </div>
//           )}



//           <div className="sidebar-item" onClick={() => toggleDropdown('academics')}>
//           <i class="fas fa-pen"></i>

//             <a href="#">Academics</a>
//             <i className={`icon-arrow ${dropdowns.academics ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.academics && (
//             <div className="dropdown">
//               <Link to="/create-subject" className="dropdown-item">Create Subject</Link>
//               <Link to="/assign-subjects" className="dropdown-item">Assign Subject</Link>
//               <Link to="/assign-subject-teacher" className="dropdown-item">Assign Subject Teacher</Link>
//               <Link to="/create-timetable" className="dropdown-item">Create Time Table</Link>
//               <Link to="/student-activities" className="dropdown-item">Student Activities</Link>
//                <Link to="/student-discipline-form" className="dropdown-item">Student Discipline</Link>
//             </div>
            
//           )}



//         <div className="sidebar-item" onClick={() => toggleDropdown('finance')}>
//             <i className="fas fa-balance-scale"></i>
//             <a href="#">Finance</a>
//             <i className={`icon-arrow ${dropdowns.finance ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.finance && (
//             <div className="dropdown">
//               <Link to="/charts-of-account-head" className="dropdown-item">Charts Of Account (Heads)</Link>
//               <Link to="/charts-of-account" className="dropdown-item">Charts Of Account</Link>
//               <Link to="/create-voucher" className="dropdown-item">Create Voucher</Link>
//               <Link to="/finance-report" className="dropdown-item">Finance Report</Link>
//             </div>
//           )}


//         </div>
//         )}



// {user && user.user.user_type =='Student' && (
//         <div className='pl-3'>
//           <div className="sidebar-item" onClick={() => toggleDropdown('lms')}>
//             <i className="fas fa-graduation-cap"></i>
//             <a href="#">LMS</a>
//             <i className={`icon-arrow ${dropdowns.lms ? 'open' : ''}`}></i>
//           </div>
//           {dropdowns.lms && (
//             <div className="dropdown">
//               <Link to="/student-profile" className="dropdown-item">Student Profile</Link>
//               <Link to="/promote-students" className="dropdown-item">Time Table</Link>
//               <Link to="/admission-list" className="dropdown-item">Class Syllabus</Link>
//               <Link to="/create-class" className="dropdown-item">Fee Vouchers</Link>
//               <Link to="/create-section" className="dropdown-item">Home Work</Link>
//             </div>
//           )}

          

//         </div>
//         )}



//         <div className='pl-3'>

//         <div className="sidebar-item" onClick={() => toggleDropdown('auth')}>
//                     <i className="fas fa-lock"></i>
//                     <a href="#">Auth</a>
//                     <i className={`icon-arrow ${dropdowns.auth ? 'open' : ''}`}></i>
//                   </div>
//                   {dropdowns.auth && (
//                     <div className="dropdown">
//                         <Link to="/add-campus-information" className="dropdown-item">Campus Information</Link>
//                        <Link to="/view-logs" className="dropdown-item">Logs</Link>
//                         <a href="#" className="dropdown-item" onClick={handleLogout}>Logout</a>
//                     </div>
//                   )}
//           </div>


//       </div>

//       {user && user.user.user_type !=='Student' && (
//       <button className="toggle-button" onClick={toggleSidebar}>
//         {isSidebarVisible ? 'Hide' : 'Show'}
//       </button>
//       )}
//     </>
//   );
// };

// export default Sidebar;




import React, { useState } from 'react';
import '../Sidebar.css';
import authService from './services/authService';
import { Link } from 'react-router-dom';
import { useAuth } from './AuthContext';

const Sidebar = () => {
  const [dropdowns, setDropdowns] = useState({
    admission: false,
    attendance: false,
    exam: false,
    fee: false,
    hr: false,
    academics: false,
    finance: false,
    lms: false,
    auth: false,
  });

  const [isSidebarVisible, setIsSidebarVisible] = useState(false);

  const { user } = useAuth();

  const toggleDropdown = (name) => {
    setDropdowns(prevState => {
      const newState = {
        admission: false,
        attendance: false,
        exam: false,
        fee: false,
        hr: false,
        academics: false,
        finance: false,
        lms: false,
        auth: false,
      };
      newState[name] = !prevState[name];
      return newState;
    });
  };

  const toggleSidebar = () => {
    setIsSidebarVisible(!isSidebarVisible);
  };

  const handleLogout = () => {
    authService.logout();
    window.location.reload();
  };

  return (
    <>
      <div className={`sidebar ${isSidebarVisible ? 'show' : 'hide'} ${user.user.user_type == 'Student' || user.user.user_type == 'Teacher' ? 'd-none' : ''}`}>
        <h4 className='p-2 text-center' style={{background:'#EBD197'}}> 
          <Link to="/" className="dropdown-item" style={{color:'black', fontWeight: 'bolder'}}>
            <i className="fas fa-tachometer-alt"></i> Dashboard
          </Link>
        </h4>
        
        {user && user.user.user_type == 'Admin' && (
          <div className='pl-3'>
            <div className="sidebar-item" onClick={() => toggleDropdown('admission')}>
              <i className="fas fa-graduation-cap"></i>
              <a href="#">Student Information</a>
              <i className={`icon-arrow ${dropdowns.admission ? 'open' : ''}`}></i>
            </div>
            {dropdowns.admission && (
              <div className="dropdown">
                <Link to="/admission-form" className="dropdown-item"><i className="fas fa-user-plus"></i> Create Admission</Link>
                <Link to="/promote-students" className="dropdown-item"><i className="fas fa-arrow-up"></i> Promote Students</Link>
                <Link to="/admission-list" className="dropdown-item"><i className="fas fa-list"></i> Admission List</Link>
                <Link to="/create-class" className="dropdown-item"><i className="fas fa-chalkboard"></i> Create Class</Link>
                <Link to="/create-section" className="dropdown-item"><i className="fas fa-object-group"></i> Create Section</Link>
                <Link to="/create-fee-group" className="dropdown-item"><i className="fas fa-money-bill"></i> Create Fee Group</Link>
                <Link to="/select-categories" className="dropdown-item"><i className="fas fa-tags"></i> Create Categories</Link>
                <Link to="/student-id-card-generate" className="dropdown-item"><i className="fas fa-id-card"></i> Student ID Card</Link>
                <Link to="/student-accounts" className="dropdown-item"><i className="fas fa-user-shield"></i> Student Accounts</Link>
                <Link to="/create-house-and-club" className="dropdown-item"><i className="fas fa-home"></i> Create House/Club</Link>
              </div>
            )}

            <div className="sidebar-item" onClick={() => toggleDropdown('attendance')}>
              <i className="fas fa-chalkboard-teacher"></i>
              <a href="#">Attendance</a>
              <i className={`icon-arrow ${dropdowns.attendance ? 'open' : ''}`}></i>
            </div>
            {dropdowns.attendance && (
              <div className="dropdown">
                <Link to="/student-attendance-list" className="dropdown-item"><i className="fas fa-user-check"></i> Student Attendance</Link>
                <Link to="/attendance-list" className="dropdown-item"><i className="fas fa-users"></i> Employee Attendance</Link>
                <Link to="/real-time-attendance-dashboard" className="dropdown-item"><i className="fas fa-users"></i> Biometric (DB)</Link>
              </div>
            )}

            <div className="sidebar-item" onClick={() => toggleDropdown('exam')}>
              <i className="fas fa-book"></i>
              <a href="#">Exam</a>
              <i className={`icon-arrow ${dropdowns.exam ? 'open' : ''}`}></i>
            </div>
            {dropdowns.exam && (
              <div className="dropdown">
                <a href="#" className="dropdown-item"><i className="fas fa-plus-circle"></i> Create Exam</a>
                <a href="#" className="dropdown-item"><i className="fas fa-marker"></i> Add Marks</a>
                <a href="#" className="dropdown-item"><i className="fas fa-file-alt"></i> Exam Report</a>
              </div>
            )}

            <div className="sidebar-item" onClick={() => toggleDropdown('fee')}>
              <i className="fas fa-receipt"></i>
              <a href="#">Fee</a>
              <i className={`icon-arrow ${dropdowns.fee ? 'open' : ''}`}></i>
            </div>
            {dropdowns.fee && (
              <div className="dropdown">
                <Link to="/bank-details-form" className="dropdown-item"><i className="fas fa-university"></i> Bank Detail</Link>
                <Link to="/bank-notes" className="dropdown-item"><i className="fas fa-sticky-note"></i> Voucher Notes</Link>
                <Link to="/heads" className="dropdown-item"><i className="fas fa-money-check-alt"></i> Fee Head</Link>
                <Link to="/fee-head-details" className="dropdown-item"><i className="fas fa-info-circle"></i> Fee Head Details</Link>
                <Link to="/fee-generate" className="dropdown-item"><i className="fas fa-file-invoice-dollar"></i> Fee Generate</Link>
                <Link to="/fee-vouchers" className="dropdown-item"><i className="fas fa-ticket-alt"></i> Fee Vouchers</Link>
                <Link to="/fee-post" className="dropdown-item"><i className="fas fa-upload"></i> Fee Post</Link>
                <Link to="/fee-post-all" className="dropdown-item"><i className="fas fa-cloud-upload-alt"></i> Fee Post All</Link>
                <Link to="/fee-reports" className="dropdown-item"><i className="fas fa-chart-bar"></i> Fee Reports</Link>
              </div>
            )}

            <div className="sidebar-item" onClick={() => toggleDropdown('hr')}>
              <i className="fas fa-users"></i>
              <a href="#">HR</a>
              <i className={`icon-arrow ${dropdowns.hr ? 'open' : ''}`}></i>
            </div>
            {dropdowns.hr && (
              <div className="dropdown">
                <Link to="/employee-form" className="dropdown-item"><i className="fas fa-user-plus"></i> Add Employee</Link>
                <Link to="/employee-list" className="dropdown-item"><i className="fas fa-users"></i> Employee List</Link>
                <Link to="/employee-id-card-generate" className="dropdown-item"><i className="fas fa-id-card"></i> Employee ID Card</Link>
                <Link to="/increments-pay-scale-wise" className="dropdown-item"><i className="fas fa-arrow-up"></i> Increments</Link>
                <Link to="/overtime" className="dropdown-item"><i className="fas fa-clock"></i> Overtime</Link>
                <Link to="/salary-of-employee" className="dropdown-item"><i className="fas fa-money-check"></i> Generate Salary</Link>
                <Link to="/school-salary-list" className="dropdown-item"><i className="fas fa-list-alt"></i> Salary List</Link>
                <Link to="/employee-discipline-form" className="dropdown-item"><i className="fas fa-user-shield"></i> Employee Discipline</Link>
                <Link to="/salary-reports" className="dropdown-item"><i className="fas fa-chart-line"></i> Salary Report</Link>
              </div>
            )}


             <div className="sidebar-item" onClick={() => toggleDropdown('website')}>
              <i className="fas fa-users"></i>
              <a href="#">Website</a>
              <i className={`icon-arrow ${dropdowns.website ? 'open' : ''}`}></i>
            </div>
            {dropdowns.website && (
              <div className="dropdown">
                <Link to="/notification" className="dropdown-item"><i class="fas fa-bell"></i> Notification</Link>
                 <Link to="/event-photos-get" className="dropdown-item"><i class="fas fa-bell"></i> Events Photo</Link>
                  <Link to="/apply-now-list" className="dropdown-item"><i class="fas fa-list"></i> Apply Now List</Link>
              </div>
              
            )}

            <div className="sidebar-item" onClick={() => toggleDropdown('academics')}>
              <i className="fas fa-pen"></i>
              <a href="#">Academics</a>
              <i className={`icon-arrow ${dropdowns.academics ? 'open' : ''}`}></i>
            </div>
            {dropdowns.academics && (
              <div className="dropdown">
                <Link to="/create-subject" className="dropdown-item"><i className="fas fa-book-open"></i> Create Subject</Link>
                <Link to="/assign-subjects" className="dropdown-item"><i className="fas fa-tasks"></i> Assign Subject</Link>
                <Link to="/assign-subject-teacher" className="dropdown-item"><i className="fas fa-chalkboard-teacher"></i> Assign Subject Teacher</Link>
                <Link to="/create-timetable" className="dropdown-item"><i className="fas fa-calendar-alt"></i> Create Time Table</Link>
                <Link to="/student-activities" className="dropdown-item"><i className="fas fa-running"></i> Student Activities</Link>
                <Link to="/student-discipline-form" className="dropdown-item"><i className="fas fa-user-shield"></i> Student Discipline</Link>
              </div>
            )}

            <div className="sidebar-item" onClick={() => toggleDropdown('finance')}>
              <i className="fas fa-balance-scale"></i>
              <a href="#">Finance</a>
              <i className={`icon-arrow ${dropdowns.finance ? 'open' : ''}`}></i>
            </div>
            {dropdowns.finance && (
              <div className="dropdown">
                <Link to="/charts-of-account-head" className="dropdown-item"><i className="fas fa-sitemap"></i> COA (Head)</Link>
                <Link to="/charts-of-account" className="dropdown-item"><i className="fas fa-stream"></i> Charts Of Account</Link>
                <Link to="/create-voucher" className="dropdown-item"><i className="fas fa-file-invoice"></i> Create Voucher</Link>
                <Link to="/finance-report" className="dropdown-item"><i className="fas fa-chart-pie"></i> Finance Report</Link>
              </div>
            )}
          </div>
        )}

        {user && user.user.user_type == 'Student' && (
          <div className='pl-3'>
            <div className="sidebar-item" onClick={() => toggleDropdown('lms')}>
              <i className="fas fa-graduation-cap"></i>
              <a href="#">LMS</a>
              <i className={`icon-arrow ${dropdowns.lms ? 'open' : ''}`}></i>
            </div>
            {dropdowns.lms && (
              <div className="dropdown">
                <Link to="/student-profile" className="dropdown-item"><i className="fas fa-user"></i> Student Profile</Link>
                <Link to="/promote-students" className="dropdown-item"><i className="fas fa-calendar-alt"></i> Time Table</Link>
                <Link to="/admission-list" className="dropdown-item"><i className="fas fa-book"></i> Class Syllabus</Link>
                <Link to="/create-class" className="dropdown-item"><i className="fas fa-ticket-alt"></i> Fee Vouchers</Link>
                <Link to="/create-section" className="dropdown-item"><i className="fas fa-book-open"></i> Home Work</Link>
              </div>
            )}
          </div>
        )}

        <div className='pl-3'>
          <div className="sidebar-item" onClick={() => toggleDropdown('auth')}>
            <i className="fas fa-lock"></i>
            <a href="#">Auth</a>
            <i className={`icon-arrow ${dropdowns.auth ? 'open' : ''}`}></i>
          </div>
          {dropdowns.auth && (
            <div className="dropdown">
              <Link to="/add-campus-information" className="dropdown-item"><i className="fas fa-school"></i> Campus Information</Link>
              <Link to="/view-logs" className="dropdown-item"><i className="fas fa-history"></i> Logs</Link>
              <a href="#" className="dropdown-item" onClick={handleLogout}><i className="fas fa-sign-out-alt"></i> Logout</a>
            </div>
          )}
        </div>
      </div>

      {user && user.user.user_type !== 'Student' && (
        <button className="toggle-button" onClick={toggleSidebar}>
          {isSidebarVisible ? 'Hide' : 'Show'}
        </button>
      )}
    </>
  );
};

export default Sidebar;
