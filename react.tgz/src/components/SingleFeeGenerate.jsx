import React, { useEffect, useState, useContext } from "react";
import axios from "axios";
import { useAuth } from "./AuthContext";
import AcademicSessionContext from "./AcademicSessionContext";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Select from "react-select";

function SingleFeeGenerate() {
  const [data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [getCategories, setCategories] = useState([]);
  const [getClasses, setClasses] = useState([]);
  const [getStudents, setStudents] = useState([]);

  const [checkAdvance, setAdvance] = useState([]);
  const [checkAdvanceStatus, setAdvanceStatus] = useState('');

  const [getFeeHeads, setFeeHeads] = useState([]);
  const { user } = useAuth();
  const { academicSession } = useContext(AcademicSessionContext);

  //this is heads_amounts state that we selected and send to server
  const [selectedItems, setSelectedItems] = useState([]);

  // useEffect(() => {
  //   const initialSelectedItems = data.map((head_detail) => ({
  //     id: head_detail.id,
  //     amount: head_detail.amount,
  //     category_id: head_detail.category_id,
  //     category_name: head_detail.category,
  //   }));
  //   setSelectedItems(initialSelectedItems);
  //   console.log(initialSelectedItems);
  // }, [data]);

  const initialState = {
    class_id: "",
    section_id: "",
    student_id: "",
    student_unique_id:"",
    shift: "",
    from_month: "",
    to_month: "",
    due_date: "",
    remarks: "",
    heads_with_amount: "",
    category_id: "",
    fee_group_id: "",
    arrear_set: true,
    bus_fee_status: true, //send to server to get bus fee or not
    bus_status: "", //show input or not
    bus_fee: 0,
    fine: 0,
    advance: 0,
    amount: "",
    session_id: academicSession,
    campus_id: user.user.campus_id,
    user_id: user.user.user_id,
    hidden_id: "",
  };

  const [validity, setValidity] = useState({
    class_id: true,
    // student_id: true,
    from_month: true,
    // to_month: true,
    due_date: true,
    remarks: true,
    advance: true,
    shift: true,
  });

  const [editFormData, setEditFormData] = useState(initialState);

  useEffect(() => {
    if (academicSession) {
      setEditFormData((prevFormData) => ({
        ...prevFormData,
        session_id: parseInt(academicSession),
      }));
    }
  }, [academicSession]);

  const validateForm = () => {
    let isValid = true;
    // Basic validation rules (customize as per your requirements)
    if (!editFormData.class_id && !editFormData.class_id.trim()) {
      setValidity((prevState) => ({ ...prevState, class_id: false }));
      isValid = false;
    }

    if (!editFormData.from_month && !editFormData.from_month.trim()) {
      setValidity((prevState) => ({ ...prevState, from_month: false }));
      isValid = false;
    }

    if (!editFormData.due_date && !editFormData.due_date.trim()) {
      setValidity((prevState) => ({ ...prevState, due_date: false }));
      isValid = false;
    }

    if (!editFormData.remarks && !editFormData.remarks.trim()) {
      setValidity((prevState) => ({ ...prevState, remarks: false }));
      isValid = false;
    }

    if (!editFormData.shift && !editFormData.shift.trim()) {
      setValidity((prevState) => ({ ...prevState, shift: false }));
      isValid = false;
    }

    return isValid;
  };

  const [report, getAllReports] = useState({
    from_date: "",
    to_date: "",
    report_type: "",
  });

  const [searchCategoryReport, getSearchCategoryReport] = useState({
    search: "",
  });

  function searchCategory() {
    // fetchData();
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      getSearchCategoryReport(searchCategoryReport);
      // fetchData();
    }
  };

  function getReport() {
    if (report.report_type == "pdf") {
      // pdfReport();
    } else if (report.report_type == "excel") {
      // excelReport();
    }
  }

  useEffect(() => {
    const getClasses = (campus_id) => {
      axios
        .get(process.env.REACT_APP_API_BASE_URL + `/get-classes/${campus_id}`)
        .then((res) => {
          setClasses(res.data.results);
        })
        .catch((err) => console.log(err));
    };

    // Ensure user.campus_id is defined before calling fetchClasses
    if (user && user.user.campus_id) {
      getClasses(user.user.campus_id);
    }
  }, [user]); // Dependenci

  useEffect(() => {
    const getStudents = (class_id, section_id, shift, campus_id, session_id) => {
      axios
        .get(
          process.env.REACT_APP_API_BASE_URL +
            `/get-students/${class_id}/${section_id}/${campus_id}/${session_id}/${shift}`
        )
        .then((res) => {
          setStudents(res.data.results);
        })
        .catch((err) => console.log(err));
    };

    // Ensure user.campus_id is defined before calling fetchClasses
    if (
      user &&
      user.user.campus_id &&
      editFormData.class_id &&
      editFormData.section_id &&
      editFormData.shift
    ) {
      getStudents(
        editFormData.class_id,
        editFormData.section_id,
        editFormData.shift,
        user.user.campus_id,
        academicSession
      );
    }
  }, [user, editFormData.class_id, editFormData.section_id, editFormData.shift]); // Dependenci

  useEffect(() => {
    const getStudents = (student_id, campus_id, session_id) => {
      axios
        .get(
          process.env.REACT_APP_API_BASE_URL +
            `/check-advance/${student_id}/${campus_id}/${session_id}`
        )
        .then((res) => {
          setAdvance(res.data.advance_payments);
          setAdvanceStatus(res.data.status);
          // setEditFormData({
          //     ...editFormData,
          //     advance : res.data.advance_payments
          // })
        })
        .catch((err) => console.log(err));
    };

    // Ensure user.campus_id is defined before calling fetchClasses
    if (user && user.user.campus_id && editFormData.student_id) {
      getStudents(
        editFormData.student_id,
        user.user.campus_id,
        academicSession
      );
    }
  }, [editFormData.student_id]); // Dependenci

  useEffect(() => {
    setSelectedItems([]); // Reset selected items when class_id or shift changes
    //for fetching heads
    const voucher_type = "single_voucher_form";

    const getClasses = (campus_id, class_id, shift, category_id) => {
      axios
        .get(
          process.env.REACT_APP_API_BASE_URL +
            `/get-fee-heads-details-for-vouchers/${campus_id}/${voucher_type}/${category_id}/${class_id}/${shift}/`
        )
        .then((res) => {
          const fetchedData = res.data.results;

          const selectedAlwaysChecked = fetchedData.filter(
            (item) => item.checked_status === "always_checked"
          );
          const alwaysCheckedItems = selectedAlwaysChecked.map((item) => ({
            id: item.id,
            amount: item.amount,
            category_id: item.category_id,
            category_name: item.category,
            head_name: item.head_name,
          }));

          setData(fetchedData);
          setSelectedItems((prevSelectedItems) => [
            ...prevSelectedItems,
            ...alwaysCheckedItems,
          ]); // Add always checked items to selected

          setLoading(false);
        })
        .catch((err) => console.log(err));
    };

    // Ensure user.campus_id is defined before calling fetchClasses
    if (
      user &&
      user.user.campus_id &&
      editFormData.class_id &&
      editFormData.shift &&
      editFormData.category_id
    ) {
      getClasses(
        user.user.campus_id,
        editFormData.class_id,
        editFormData.shift,
        editFormData.category_id
      );
    }
  }, [editFormData.class_id, editFormData.shift, editFormData.category_id]); // Dependenci

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (selectedItems.length <= 0) {
      toast.error("No fee head selected!");
      return;
    }
    if (validateForm()) {
      let groupedData = {};

      // Iterate through each item in the data array
      console.log(selectedItems);
      selectedItems.forEach((item) => {
        const { category_id, head_name, ...rest } = item;

        // Check if the category_id already exists in groupedData
        if (groupedData[category_id]) {
          // If exists, push the item to the existing array
          groupedData[category_id].push(rest);
        } else {
          // If doesn't exist, create a new array with the item
          groupedData[category_id] = [rest];
        }
      });

      const combinedData = {
        editFormData,
        groupedData,
      };

      // console.log(selectedItems.length);

      try {
        const response = await fetch(
          process.env.REACT_APP_API_BASE_URL + "/single-fee-voucher",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              // Add any other headers if needed, like authorization headers
            },
            body: JSON.stringify(combinedData), // Convert your data to JSON format
          }
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const responseData = await response.json(); // Parse the JSON response

        if (responseData.message == "greater_month") {
          toast.error("Voucher month shoudld be greater! Last Entry Voucher");
        } else {
          toast.success("Fee vouchers submitted successfully!");
          setEditFormData({
            ...editFormData,
            student_id: "",
            class_id: "",
            advance: 0,
            bus_fee: 0,
          });
          setSelectedItems([]);
          // setEditFormData(initialState);
        }

        // Handle the responseData as needed
        // console.log('Response:', responseData);
      } catch (error) {
        console.error("Error:", error);
      }
    }
  };

  useEffect(() => {
    if (editFormData.from_month) {
      const selectedMonth = new Date(editFormData.from_month);
      const dueDate = new Date(
        selectedMonth.getFullYear(),
        selectedMonth.getMonth(),
        2
      ); // Set due date to the 5th of the next month
      setEditFormData((prevFormData) => ({
        ...prevFormData,
        due_date: dueDate.toISOString().split("T")[0],
      }));
    }
  }, [editFormData.from_month]);

  const handleCheckboxChange = (id, amount, category_id, category_name) => {
    setSelectedItems((prevSelectedItems) => {
      const isSelected = prevSelectedItems.some((item) => item.id === id);
      if (isSelected) {
        // If the item is already selected, remove it
        return prevSelectedItems.filter((item) => item.id !== id);
      } else {
        // If the item is not selected, add it
        return [
          ...prevSelectedItems,
          { id, amount, category_id, category_name },
        ];
      }
    });
  };

  const handleAmountChange = (e, id) => {
    const newAmount = e.target.value;
    setSelectedItems((prevSelectedItems) => {
      return prevSelectedItems.map((item) => {
        if (item.id === id) {
          return { ...item, amount: parseInt(newAmount) };
        }
        return item;
      });
    });
  };

  const findClassLabel = () => {
    if (!editFormData.class_id || !editFormData.section_id) {
      return "";
    }
    const classObj = getClasses.find(
      (class_get) =>
        class_get.id === parseInt(editFormData.class_id) &&
        class_get.section_id === parseInt(editFormData.section_id)
    );
    if (classObj) {
      return `${classObj.class} (${classObj.section_name})`;
    }
    return "";
  };

  const handleClassChange = (selectedOption) => {
    const [class_id, section_id] = selectedOption
      ? selectedOption.value.split(",")
      : ["", ""];
    setEditFormData({ ...editFormData, class_id, section_id });
  };

  const grandAmount = selectedItems.reduce(
    (total, item) => parseInt(total) + parseInt(item.amount),
    0
  );

  const handleStudentChange = (selectedOption) => {
    const student = getStudents.find(
      (student) => student.id === selectedOption.value
    );

    console.log(selectedOption.student_unique_id, "unique");
    setEditFormData({
      ...editFormData,
      student_id: selectedOption ? selectedOption.value : "",
      category_id: selectedOption ? selectedOption.category_id : "", // Update category_id on change
      shift: selectedOption ? selectedOption.shift : "", // Update shift on change,
      student_unique_id : selectedOption ? selectedOption.student_unique_id : "",
      bus_fee: student ? student.bus_fee : 0, // Set bus_fee from selected student
      bus_status: student ? student.bus_status : "", // Set bus_status from selected student
    });
  };

  return (
    <>
      <div className="d-flex">
        <div className="col-md-4 p-2">
          {/* <h5 className="text-warning bg-primary p-2 card-header border">
            {" "}
            <i className="fas fa-file-invoice"></i> Single Fee Generate
          </h5> */}
          <form className="border p-3">
            <div className="form-group row">
              <label className="col-sm-2 form-label">Arrear</label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="arrear_set"
                    value="true"
                    checked={editFormData.arrear_set === true}
                    onChange={() =>
                      setEditFormData({ ...editFormData, arrear_set: true })
                    }
                  />
                  <label className="form-check-label">Yes</label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="arrear_set"
                    value="false"
                    checked={editFormData.arrear_set === false}
                    onChange={() =>
                      setEditFormData({ ...editFormData, arrear_set: false })
                    }
                  />
                  <label className="form-check-label">No</label>
                </div>
              </div>
            </div>

            <div className="form-group row">
              <label className="col-sm-2 form-label">Bus</label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="bus_fee_status"
                    value="true"
                    checked={editFormData.bus_fee_status === true}
                    onChange={() =>
                      setEditFormData({ ...editFormData, bus_fee_status: true })
                    }
                  />
                  <label className="form-check-label">Yes</label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="bus_fee_status"
                    value="false"
                    checked={editFormData.bus_fee_status === false}
                    onChange={() =>
                      setEditFormData({
                        ...editFormData,
                        bus_fee_status: false,
                      })
                    }
                  />
                  <label className="form-check-label">No</label>
                </div>
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Class
              </label>
              <div className="col-sm-10 ">
                <Select
                  options={getClasses.map((class_get) => ({
                    value: `${class_get.id},${class_get.section_id}`,
                    label: `${class_get.class} (${class_get.section_name})`,
                  }))}
                  value={
                    editFormData.class_id && editFormData.section_id
                      ? {
                          value: `${editFormData.class_id},${editFormData.section_id}`,
                          label: findClassLabel(),
                        }
                      : { value: "", label: "Select Class" }
                  }
                  onChange={handleClassChange}
                  placeholder="Select Class"
                  isClearable
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Shift
              </label>
              <div className="col-sm-10 ">
                <select
                  name="shift"
                  id="shift"
                  className={
                    validity.shift
                      ? "form-control"
                      : "form-control invalid-input"
                  }
                  value={editFormData.shift}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      shift: e.target.value,
                    });
                    setValidity({ ...validity, shift: true });
                  }}
                >
                  <option value="">Select Shift</option>
                  <option>Morning</option>
                  <option>Evening</option>
                </select>
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Students
              </label>
              <div className="col-sm-10 ">
                <Select
                  options={getStudents.map((student) => ({
                    value: student.id,
                    label: student.full_name,
                    category_id: student.category_id,
                    shift: student.shift,
                    student_unique_id:student.student_unique_id
                  }))}
                  value={
                    editFormData.student_id
                      ? {
                          value: editFormData.student_id,
                          label:
                            getStudents.find(
                              (student) =>
                                student.id === editFormData.student_id
                            )?.full_name || "",
                          category_id: editFormData.category_id,
                          shift: editFormData.shift,
                          student_unique_id:editFormData.student_unique_id
                        }
                      : null
                  }
                  onChange={handleStudentChange}
                  placeholder="Select Student"
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Month
              </label>
              <div className="col-sm-10 ">
                <input
                  type="month"
                  name="amount"
                  value={editFormData.from_month}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      from_month: e.target.value,
                      to_month: e.target.value,
                    });
                    setValidity({ ...validity, from_month: true });
                  }}
                  className={
                    validity.from_month
                      ? "form-control"
                      : "form-control invalid-input"
                  }
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Due_Date
              </label>
              <div className="col-sm-10 ">
                <input
                  type="date"
                  name="due_date"
                  value={editFormData.due_date}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      due_date: e.target.value,
                    });
                    setValidity({ ...validity, due_date: true });
                  }}
                  className={
                    validity.due_date
                      ? "form-control"
                      : "form-control invalid-input"
                  }
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Fine
              </label>
              <div className="col-sm-10 ">
                <input
                  type="text"
                  name="fine"
                  value={editFormData.fine}
                  onChange={(e) => {
                    setEditFormData({ ...editFormData, fine: e.target.value });
                  }}
                  className={"form-control"}
                />
              </div>
            </div>
            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Remarks
              </label>
              <div className="col-sm-10 ">
                <input
                  type="text"
                  name="remarks"
                  value={editFormData.remarks}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      remarks: e.target.value,
                    });
                    setValidity({ ...validity, remarks: true });
                  }}
                  className={
                    validity.remarks
                      ? "form-control"
                      : "form-control invalid-input"
                  }
                />
              </div>
            </div>

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Advance
              </label>
              <div className="col-sm-10">
                <input
                  type="number"
                  name="advance"
                  value={editFormData.advance}
                  onChange={(e) => {
                    setEditFormData({
                      ...editFormData,
                      advance: e.target.value,
                    });
                  }}
                  className={"form-control"}
                  readOnly={checkAdvance > 0 && checkAdvanceStatus == 'paid'} // Conditionally set the readOnly attribute
                  // placeholder={
                  //   checkAdvance > 0
                  //     ? "*Remaining Advance (" + checkAdvance + ")"
                  //     : "Enter advance amount"
                  // } // Default placeholder when no advance exists
                />
                 {
                    checkAdvance > 0 && checkAdvanceStatus == 'paid'
                      ? "*Remaining Advance (" + checkAdvance + ")"
                      : "Enter advance amount"
                  } 
              </div>
              
            </div>
                 

            <div className="form-group row">
              <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">
                Bus_Fee
              </label>
              <div className="col-sm-10 ">
                <input
                  type="number"
                  name="bus_fee"
                  value={editFormData.bus_fee}
                  readOnly
                  className={"form-control"}
                />
              </div>
            </div>
          </form>
        </div>

        <div className="col-md-8 p-2">
          <div className="card-header text-warning bg-primary p-2">
            <div className="d-flex justify-content-between align-items-center">
              <div>
                <i className="fas fa-list"></i> Heads Detail
              </div>

              {/* search category */}

              <div className="d-flex">
                <div className="me-2 mr-2">
                  <input
                    type="text"
                    className="form-control"
                    id="search_category"
                    onKeyDown={handleKeyDown}
                    onChange={(e) =>
                      getSearchCategoryReport({
                        ...searchCategoryReport,
                        search: e.target.value,
                      })
                    }
                  />
                </div>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={searchCategory}
                >
                  Search
                </button>
              </div>

              <div className="d-none">
                <div className="me-2 mr-2">
                  <input
                    type="date"
                    className="form-control"
                    id="from_date"
                    onChange={(e) =>
                      getAllReports({ ...report, from_date: e.target.value })
                    }
                  />
                </div>

                <div className="me-2 mr-2">
                  <input
                    type="date"
                    className="form-control"
                    id="to_date"
                    onChange={(e) =>
                      getAllReports({ ...report, to_date: e.target.value })
                    }
                  />
                </div>

                <div className="me-2 mr-2">
                  <select
                    name="type"
                    id="type"
                    className="form-control"
                    onChange={(e) =>
                      getAllReports({ ...report, report_type: e.target.value })
                    }
                  >
                    <option value="">Select Type</option>

                    <option value="excel">Excel</option>
                    <option value="pdf">PDF</option>
                  </select>
                </div>

                <button className="btn btn-sm btn-danger" onClick={getReport}>
                  Get Report
                </button>
              </div>
            </div>
          </div>

          <div className="border p-2">
            <table className="table">
              <thead>
                <tr>
                  {/* <th>ID</th> */}
                  <th>Head</th>
                  <th>Category</th>
                  <th>Amount</th>
                  <th className="text-center">Active</th>
                </tr>
              </thead>
              <tbody>
                {data.map((head_detail, index) => (
                  <tr key={index}>
                    <td>{head_detail.head_name}</td>
                    <td>{head_detail.category}</td>
                    <td>
                      {selectedItems.some(
                        (item) => item.id === head_detail.id
                      ) ? (
                        <input
                          type="text"
                          value={
                            selectedItems.find(
                              (item) => item.id === head_detail.id
                            )?.amount || head_detail.amount
                          }
                          onChange={(e) =>
                            handleAmountChange(e, head_detail.id)
                          }
                        />
                      ) : (
                        head_detail.amount
                      )}
                    </td>
                    <td className="text-center">
                      <div>
                        <input
                          type="checkbox"
                          id={`head_detail_${head_detail.id}`}
                          checked={selectedItems.some(
                            (item) => item.id === head_detail.id
                          )}
                          onChange={() =>
                            handleCheckboxChange(
                              head_detail.id,
                              head_detail.amount,
                              head_detail.category_id,
                              head_detail.category
                            )
                          }
                        />
                      </div>
                    </td>
                  </tr>
                ))}
                <tr>
                  <td style={{ textAlign: "right" }} colSpan={"4"}>
                    <input
                      type="submit"
                      className="btn btn-sm btn-primary"
                      value={"Save"}
                      onClick={handleSubmit}
                    />
                  </td>
                </tr>
              </tbody>
              <tfoot>
                {selectedItems.length > 0 && (
                  <tr>
                    <td style={{ fontWeight: "bolder" }}>Grand Total</td>
                    <td>
                      {grandAmount +
                        editFormData.bus_fee +
                        parseInt(editFormData.advance)}
                    </td>
                  </tr>
                )}
                {selectedItems.length === 0 && (
                  <tr>
                    <td colSpan="2">No Head selected</td>
                  </tr>
                )}
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}

export default SingleFeeGenerate;
