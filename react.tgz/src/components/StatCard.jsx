import React from 'react';
import { Card, CardContent, Typography, Box } from '@mui/material';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import PeopleIcon from '@mui/icons-material/People';
import SchoolIcon from '@mui/icons-material/School';
import PersonIcon from '@mui/icons-material/Person';
import FeedbackIcon from '@mui/icons-material/Feedback';
import ReceiptIcon from '@mui/icons-material/Receipt';

const iconMap = {
  employee: <PeopleIcon fontSize="large" style={{ color: '#000000' }} />,
  students: <SchoolIcon fontSize="large" style={{ color: '#000000' }} />,
  parents: <PersonIcon fontSize="large" style={{ color: '#000000' }} />,
  complaints: <FeedbackIcon fontSize="large" style={{ color: '#000000' }} />,
  voucher: <ReceiptIcon fontSize="large" style={{ color: '#000000' }} />,
  income: <AttachMoneyIcon fontSize="large" style={{ color: '#000000' }} />,
};

function StatCard({ icon, title, value, description, backgroundColor = '#FFF' }) {
  return (
    <Card sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: 2, backgroundColor }}>
      <CardContent sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          {iconMap[icon]}
          <Typography variant="h6" component="div" sx={{ ml: 2 }}>
            {title}
          </Typography>
        </Box>
        <Typography variant="h4" component="div" style={{ color: '#000000' }}>
          {value}
        </Typography>
      </CardContent>
      <Box sx={{ width: '100%', mt: 1, borderBottom: 2, borderColor: '#000000' }}></Box>
      <Typography variant="body2" color="textSecondary" sx={{ mt: 1 }}>
        {description}
      </Typography>
    </Card>
  );
}

export default StatCard;
